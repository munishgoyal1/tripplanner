import { useCallback, useState } from "react";
import { WorkspaceShell } from "@/components/shell/WorkspaceShell";
import { GlobalBanner } from "@/components/shell/GlobalBanner";
import { TripWarnings } from "@/components/shell/TripWarnings";
import { Toolbar } from "@/components/toolbar/Toolbar";
import { ItineraryPanel } from "@/components/itinerary/ItineraryPanel";
import { MapPanel } from "@/components/map/MapPanel";
import { DetailsPanel } from "@/components/details/DetailsPanel";
import { AssistantDock } from "@/components/assistant/AssistantDock";
import { MobileViewBar } from "@/components/mobile/MobileViewBar";
import { ProfileOverlay } from "@/components/profile/ProfileOverlay";
import { demoUser, places, placesById, quickActions } from "@/fixtures/demoData";
import { usePlannerState } from "@/state/usePlannerState";
import { useProfileState } from "@/state/useProfileState";
import type { WorkspaceView } from "@/types";

export default function App() {
  const planner = usePlannerState();
  const profile = useProfileState();
  const [view, setView] = useState<WorkspaceView>("split");
  const [profileOpen, setProfileOpen] = useState(false);
  const [smartDefaults, setSmartDefaults] = useState(true);

  const selectedPlace = planner.selectedPlaceId ? placesById[planner.selectedPlaceId] : undefined;

  const handleWarningAction = useCallback(
    (action: string) => {
      planner.sendMessage(action);
      planner.notify("Assistant is working on it");
    },
    [planner],
  );

  return (
    <WorkspaceShell
      view={view}
      banner={
        <GlobalBanner
          message="New: the assistant can now book-check hotels and flag price drops while you plan."
          actionLabel="See what's new"
          onAction={() => planner.notify("Opening changelog…")}
        />
      }
      toolbar={
        <Toolbar
          view={view}
          onViewChange={setView}
          notice={planner.notice}
          trips={planner.trips}
          activeTripId={planner.trip?.id}
          onSelectTrip={planner.selectTrip}
          onNewTrip={() => planner.createTrip()}
          onNotify={planner.notify}
          userName={profile.profile.displayName || demoUser.name}
          userEmail={demoUser.email}
          onOpenProfile={() => setProfileOpen(true)}
          onSignOut={() => planner.notify("Sign-out is disabled in this demo")}
        />
      }
      warnings={
        <TripWarnings
          trip={planner.trip}
          placesById={placesById}
          onAction={handleWarningAction}
        />
      }
      itinerary={
        <ItineraryPanel
          trip={planner.trip}
          placesById={placesById}
          selectedDayId={planner.dayId}
          selectedPlaceId={planner.selectedPlaceId}
          documentCount={profile.profile.documents.length}
          onSelectDay={planner.selectDay}
          onSelectPlace={planner.selectPlace}
          onHoverStop={planner.setHoveredStopId}
          onMoveStop={planner.moveStop}
          onRemoveStop={planner.removeStop}
          onRenameTrip={planner.renameTrip}
          onAddDay={planner.addDay}
        />
      }
      map={
        <MapPanel
          trip={planner.trip}
          day={planner.day}
          placesById={placesById}
          selectedDayId={planner.dayId}
          selectedPlaceId={planner.selectedPlaceId}
          hoveredStopId={planner.hoveredStopId}
          onSelectDay={planner.selectDay}
          onSelectPlace={planner.selectPlace}
        />
      }
      details={
        <DetailsPanel
          places={places}
          place={selectedPlace}
          trip={planner.trip}
          day={planner.day}
          onSelectPlace={planner.selectPlace}
          onAddPlaceToDay={planner.addPlaceToDay}
        />
      }
      assistant={
        <AssistantDock
          messages={planner.messages}
          thinking={planner.thinking}
          quickActions={quickActions}
          onSend={planner.sendMessage}
          smartDefaults={smartDefaults}
          onSmartDefaultsChange={(value) => {
            setSmartDefaults(value);
            planner.notify(
              value
                ? "Assistant will fill gaps with smart defaults"
                : "Assistant will ask before filling gaps",
            );
          }}
        />
      }
      mobileBar={<MobileViewBar view={view} onViewChange={setView} />}
      overlay={
        <ProfileOverlay
          open={profileOpen}
          onOpenChange={setProfileOpen}
          controller={profile}
          userName={demoUser.name}
          userEmail={demoUser.email}
          trip={planner.trip}
          onSignOut={() => {
            setProfileOpen(false);
            planner.notify("Sign-out is disabled in this demo");
          }}
          onNotify={planner.notify}
        />
      }
    />
  );
}
