/**
 * Single fixture file — every piece of demonstration data used by the app.
 * Presentation-only: nothing here talks to a network or a database.
 */
import type {
  ChatMessage,
  Day,
  Place,
  ProfileState,
  Trip,
} from "../types";

const hoursStandard = [
  { day: "Mon", open: "09:00 – 17:00" },
  { day: "Tue", open: "09:00 – 17:00" },
  { day: "Wed", open: "09:00 – 17:00" },
  { day: "Thu", open: "09:00 – 17:00" },
  { day: "Fri", open: "09:00 – 18:00" },
  { day: "Sat", open: "09:00 – 18:00" },
  { day: "Sun", open: "10:00 – 16:00" },
];

const hoursAlways = [
  { day: "Mon", open: "Open 24 hours" },
  { day: "Tue", open: "Open 24 hours" },
  { day: "Wed", open: "Open 24 hours" },
  { day: "Thu", open: "Open 24 hours" },
  { day: "Fri", open: "Open 24 hours" },
  { day: "Sat", open: "Open 24 hours" },
  { day: "Sun", open: "Open 24 hours" },
];

const hoursEvening = [
  { day: "Mon", open: "Closed" },
  { day: "Tue", open: "17:30 – 23:00" },
  { day: "Wed", open: "17:30 – 23:00" },
  { day: "Thu", open: "17:30 – 23:00" },
  { day: "Fri", open: "17:30 – 00:00" },
  { day: "Sat", open: "12:00 – 00:00" },
  { day: "Sun", open: "12:00 – 22:00" },
];

export const places: Place[] = [
  {
    id: "fushimi",
    name: "Fushimi Inari Taisha",
    category: "sight",
    city: "Kyoto",
    lat: 34.9671,
    lng: 135.7727,
    rating: 4.8,
    reviewCount: 48213,
    ratingBreakdown: [82, 13, 3, 1, 1],
    priceLevel: 1,
    ticket: "Free entry · no reservation",
    typicalVisitMinutes: 120,
    hours: hoursAlways,
    address: "68 Fukakusa Yabunouchicho, Fushimi Ward, Kyoto",
    phone: "+81 75-641-7331",
    website: "inari.jp",
    tags: ["Torii gates", "Sunrise", "Hiking", "Shinto shrine"],
    blurb:
      "Ten thousand vermilion torii climb the wooded slope of Mount Inari. Arrive before 07:30 and the tunnels are almost yours.",
    photo: "clay",
    reviews: [
      {
        author: "Amara P.",
        rating: 5,
        date: "2 weeks ago",
        text: "Went at 6:40am — barely another soul on the path until the Yotsutsuji lookout. Bring water, the full loop is a real climb.",
      },
      {
        author: "Devon R.",
        rating: 4,
        date: "1 month ago",
        text: "Magical, but by 10am the lower gates are shoulder to shoulder. The upper trail stays quiet all day.",
      },
    ],
  },
  {
    id: "nishiki",
    name: "Nishiki Market",
    category: "food",
    city: "Kyoto",
    lat: 35.005,
    lng: 135.7649,
    rating: 4.4,
    reviewCount: 21980,
    ratingBreakdown: [58, 29, 9, 3, 1],
    priceLevel: 2,
    ticket: "Free to browse · pay per stall",
    typicalVisitMinutes: 75,
    hours: [
      { day: "Mon", open: "09:30 – 18:00" },
      { day: "Tue", open: "09:30 – 18:00" },
      { day: "Wed", open: "09:30 – 18:00" },
      { day: "Thu", open: "09:30 – 18:00" },
      { day: "Fri", open: "09:30 – 18:00" },
      { day: "Sat", open: "09:00 – 18:00" },
      { day: "Sun", open: "09:00 – 17:00" },
    ],
    address: "Nishikikoji-dori, Nakagyo Ward, Kyoto",
    website: "kyoto-nishiki.or.jp",
    tags: ["Street food", "Tsukemono", "Covered arcade"],
    blurb:
      "Five narrow blocks of pickles, tamagoyaki, soy-milk doughnuts and knife shops. Kyoto's kitchen for four centuries.",
    photo: "ochre",
    reviews: [
      {
        author: "Lin W.",
        rating: 5,
        date: "3 weeks ago",
        text: "Grilled scallop skewers and the sesame soft serve. Eat standing by the stall — walking while eating is frowned upon here.",
      },
      {
        author: "Marcus T.",
        rating: 4,
        date: "2 months ago",
        text: "Touristy in the middle stretch, but the eastern end still serves locals. Go hungry, go early.",
      },
    ],
  },
  {
    id: "arashiyama",
    name: "Arashiyama Bamboo Grove",
    category: "nature",
    city: "Kyoto",
    lat: 35.0169,
    lng: 135.6717,
    rating: 4.5,
    reviewCount: 39440,
    ratingBreakdown: [64, 25, 8, 2, 1],
    priceLevel: 1,
    ticket: "Free entry",
    typicalVisitMinutes: 60,
    hours: hoursAlways,
    address: "Ukyo Ward, Kyoto",
    tags: ["Bamboo", "Photography", "Riverside"],
    blurb:
      "A green corridor of towering moso bamboo that hums when the wind moves through it. Pair it with the Togetsukyo bridge walk.",
    photo: "sage",
    reviews: [
      {
        author: "Priya N.",
        rating: 5,
        date: "1 week ago",
        text: "Shorter than photos suggest but genuinely beautiful at first light. The Okochi Sanso garden next door is worth the ticket.",
      },
    ],
  },
  {
    id: "kinkakuji",
    name: "Kinkaku-ji (Golden Pavilion)",
    category: "sight",
    city: "Kyoto",
    lat: 35.0394,
    lng: 135.7292,
    rating: 4.6,
    reviewCount: 52310,
    ratingBreakdown: [70, 22, 5, 2, 1],
    priceLevel: 2,
    ticket: "¥500 adult · buy at gate",
    typicalVisitMinutes: 60,
    hours: hoursStandard,
    address: "1 Kinkakujicho, Kita Ward, Kyoto",
    phone: "+81 75-461-0013",
    website: "shokoku-ji.jp",
    tags: ["Zen temple", "Gold leaf", "Reflecting pond"],
    blurb:
      "A gold-leafed pavilion mirrored in the Kyoko-chi pond. The circuit is one-way and takes about forty minutes at a slow pace.",
    photo: "ochre",
    reviews: [
      {
        author: "Sofia B.",
        rating: 5,
        date: "5 days ago",
        text: "Overcast light actually made the gold pop more than full sun. Whole visit took 45 minutes including the tea house.",
      },
      {
        author: "Kenji A.",
        rating: 4,
        date: "6 weeks ago",
        text: "You can't go inside — it's a viewing circuit. Knowing that in advance sets the right expectation.",
      },
    ],
  },
  {
    id: "gion",
    name: "Gion & Hanamikoji Street",
    category: "sight",
    city: "Kyoto",
    lat: 35.0036,
    lng: 135.7752,
    rating: 4.4,
    reviewCount: 18760,
    ratingBreakdown: [57, 30, 9, 3, 1],
    priceLevel: 2,
    ticket: "Free to walk · photography restricted on private lanes",
    typicalVisitMinutes: 90,
    hours: hoursAlways,
    address: "Hanamikoji-dori, Higashiyama Ward, Kyoto",
    tags: ["Machiya", "Evening walk", "Geiko district"],
    blurb:
      "Wooden teahouses and lantern light. Best after 17:30 when the lanterns come on and the day crowds thin out.",
    photo: "clay",
    reviews: [
      {
        author: "Hannah K.",
        rating: 5,
        date: "2 weeks ago",
        text: "Dusk is the moment. Respect the no-photo signs on the side alleys — they're enforced with fines now.",
      },
    ],
  },
  {
    id: "kiyomizu",
    name: "Kiyomizu-dera",
    category: "sight",
    city: "Kyoto",
    lat: 34.9949,
    lng: 135.785,
    rating: 4.7,
    reviewCount: 44120,
    ratingBreakdown: [74, 20, 4, 1, 1],
    priceLevel: 2,
    ticket: "¥400 adult · ¥200 child",
    typicalVisitMinutes: 90,
    hours: [
      { day: "Mon", open: "06:00 – 18:00" },
      { day: "Tue", open: "06:00 – 18:00" },
      { day: "Wed", open: "06:00 – 18:00" },
      { day: "Thu", open: "06:00 – 18:00" },
      { day: "Fri", open: "06:00 – 21:30" },
      { day: "Sat", open: "06:00 – 21:30" },
      { day: "Sun", open: "06:00 – 18:00" },
    ],
    address: "1-294 Kiyomizu, Higashiyama Ward, Kyoto",
    phone: "+81 75-551-1234",
    website: "kiyomizudera.or.jp",
    tags: ["Hillside terrace", "City views", "UNESCO"],
    blurb:
      "A cedar stage jutting over the hillside with the whole city behind it. The approach lanes are half the experience.",
    photo: "sage",
    reviews: [
      {
        author: "Tomas L.",
        rating: 5,
        date: "9 days ago",
        text: "Opens at 6am — the only way to get the terrace to yourself. Sannenzaka on the way down is empty at that hour too.",
      },
    ],
  },
  {
    id: "pontocho",
    name: "Pontocho Kappa Sushi",
    category: "food",
    city: "Kyoto",
    lat: 35.0056,
    lng: 135.7708,
    rating: 4.6,
    reviewCount: 3120,
    ratingBreakdown: [72, 20, 5, 2, 1],
    priceLevel: 3,
    ticket: "Reservation recommended · ¥6,000 omakase",
    typicalVisitMinutes: 90,
    hours: hoursEvening,
    address: "Pontocho-dori, Nakagyo Ward, Kyoto",
    phone: "+81 75-221-0123",
    tags: ["Omakase", "Counter seating", "Riverside alley"],
    blurb:
      "Eight seats on a lantern-lit alley. The chef works quietly through a set course with whatever came in that morning.",
    photo: "clay",
    reviews: [
      {
        author: "Rina S.",
        rating: 5,
        date: "1 month ago",
        text: "Booked 3 weeks ahead. Worth it — the aged madai and the tamago at the end were the highlights of the trip.",
      },
    ],
  },
  {
    id: "nara",
    name: "Nara Park & Todai-ji",
    category: "nature",
    city: "Nara",
    lat: 34.685,
    lng: 135.843,
    rating: 4.7,
    reviewCount: 61200,
    ratingBreakdown: [76, 18, 4, 1, 1],
    priceLevel: 2,
    ticket: "Park free · Todai-ji hall ¥800",
    typicalVisitMinutes: 210,
    hours: hoursStandard,
    address: "Zoshicho, Nara",
    website: "todaiji.or.jp",
    tags: ["Day trip", "Deer", "Great Buddha"],
    blurb:
      "Forty-five minutes by rapid train. Free-roaming sika deer, and the largest bronze Buddha in Japan under a vast wooden hall.",
    photo: "sage",
    reviews: [
      {
        author: "Ollie M.",
        rating: 5,
        date: "3 weeks ago",
        text: "Buy deer crackers only when you're ready — they will follow you. Todai-ji is genuinely staggering in scale.",
      },
    ],
  },
  {
    id: "teramachi",
    name: "Teramachi Arcade",
    category: "shopping",
    city: "Kyoto",
    lat: 35.007,
    lng: 135.7672,
    rating: 4.2,
    reviewCount: 8940,
    ratingBreakdown: [45, 34, 15, 4, 2],
    priceLevel: 2,
    ticket: "Free entry",
    typicalVisitMinutes: 60,
    hours: hoursStandard,
    address: "Teramachi-dori, Nakagyo Ward, Kyoto",
    tags: ["Covered arcade", "Stationery", "Rain-proof"],
    blurb:
      "Covered shopping street running north from Shijo — good rainy-afternoon insurance, and the best paper shops in the city.",
    photo: "ochre",
    reviews: [
      {
        author: "Eve C.",
        rating: 4,
        date: "2 months ago",
        text: "Great for gifts. The vintage kimono shop halfway up is a find.",
      },
    ],
  },
  {
    id: "philosopher",
    name: "Philosopher's Path",
    category: "nature",
    city: "Kyoto",
    lat: 35.0271,
    lng: 135.7943,
    rating: 4.5,
    reviewCount: 15320,
    ratingBreakdown: [62, 28, 7, 2, 1],
    priceLevel: 1,
    ticket: "Free",
    typicalVisitMinutes: 60,
    hours: hoursAlways,
    address: "Sakyo Ward, Kyoto",
    tags: ["Canal walk", "Cherry trees", "Quiet"],
    blurb:
      "Two kilometres of stone path along a cherry-lined canal, linking Ginkaku-ji to Nanzen-ji. Slow, shaded, uncrowded.",
    photo: "sage",
    reviews: [
      {
        author: "Nils H.",
        rating: 5,
        date: "1 month ago",
        text: "Do it in the late afternoon, ending at Nanzen-ji aqueduct. Cafés along the way are lovely.",
      },
    ],
  },
];

export const placesById: Record<string, Place> = Object.fromEntries(
  places.map((p) => [p.id, p]),
);

const kyotoDays: Day[] = [
  {
    id: "d1",
    date: "Mon, 14 Apr",
    title: "Arrival & east Kyoto",
    stops: [
      {
        id: "s1",
        placeId: "kiyomizu",
        startTime: "09:30",
        durationMinutes: 90,
        travelToNextMinutes: 18,
        travelMode: "walk",
        note: "Enter from Chawanzaka to skip the busiest approach.",
      },
      {
        id: "s2",
        placeId: "gion",
        startTime: "11:30",
        durationMinutes: 90,
        travelToNextMinutes: 9,
        travelMode: "walk",
      },
      {
        id: "s3",
        placeId: "nishiki",
        startTime: "13:30",
        durationMinutes: 75,
        travelToNextMinutes: 12,
        travelMode: "walk",
      },
      {
        id: "s4",
        placeId: "pontocho",
        startTime: "19:00",
        durationMinutes: 90,
      },
    ],
  },
  {
    id: "d2",
    date: "Tue, 15 Apr",
    title: "Torii sunrise & north temples",
    stops: [
      {
        id: "s5",
        placeId: "fushimi",
        startTime: "07:00",
        durationMinutes: 120,
        travelToNextMinutes: 42,
        travelMode: "metro",
        note: "Sunrise slot — the AI moved this earlier to dodge crowds.",
      },
      {
        id: "s6",
        placeId: "kinkakuji",
        startTime: "10:30",
        durationMinutes: 60,
        travelToNextMinutes: 35,
        travelMode: "metro",
      },
      {
        id: "s7",
        placeId: "philosopher",
        startTime: "15:00",
        durationMinutes: 60,
      },
    ],
  },
  {
    id: "d3",
    date: "Wed, 16 Apr",
    title: "Arashiyama & the west",
    stops: [
      {
        id: "s8",
        placeId: "arashiyama",
        startTime: "08:00",
        durationMinutes: 60,
        travelToNextMinutes: 40,
        travelMode: "metro",
      },
      {
        id: "s9",
        placeId: "teramachi",
        startTime: "14:00",
        durationMinutes: 60,
      },
    ],
  },
  {
    id: "d4",
    date: "Thu, 17 Apr",
    title: "Nara day trip",
    stops: [
      {
        id: "s10",
        placeId: "nara",
        startTime: "09:00",
        durationMinutes: 210,
      },
    ],
  },
];

export const trips: Trip[] = [
  {
    id: "kyoto-spring",
    name: "Kyoto in cherry season",
    destination: "Kyoto, Japan",
    dateRange: "14 – 18 Apr",
    travelers: 2,
    cover: "clay",
    center: [34.999, 135.768],
    days: kyotoDays,
  },
  {
    id: "lisbon-weekend",
    name: "Lisbon long weekend",
    destination: "Lisbon, Portugal",
    dateRange: "2 – 5 Jun",
    travelers: 2,
    cover: "ochre",
    center: [38.7223, -9.1393],
    days: [],
  },
  {
    id: "dolomites",
    name: "Dolomites hut-to-hut",
    destination: "South Tyrol, Italy",
    dateRange: "8 – 15 Sep",
    travelers: 4,
    cover: "sage",
    center: [46.5405, 11.9273],
    days: [],
  },
];

export const sampleItineraries = [
  {
    id: "kyoto",
    destination: "Kyoto",
    length: "5 days",
    tone: "Temples, tea and a Nara day trip",
    highlights: ["Sunrise at Fushimi Inari", "Nishiki tasting walk", "Gion after dark"],
    swatch: "clay",
  },
  {
    id: "lisbon",
    destination: "Lisbon",
    length: "3 days",
    tone: "Tiles, trams and seafood at the counter",
    highlights: ["Alfama at golden hour", "Time Out Market", "Sintra half-day"],
    swatch: "ochre",
  },
  {
    id: "dolomites",
    destination: "Dolomites",
    length: "8 days",
    tone: "Hut-to-hut with cable-car shortcuts",
    highlights: ["Tre Cime loop", "Rifugio Locatelli", "Lago di Braies dawn"],
    swatch: "sage",
  },
];


/* ------------------------------------------------------------------ */
/* Assistant                                                           */
/* ------------------------------------------------------------------ */

export const initialMessages: ChatMessage[] = [
  {
    id: "m0",
    role: "assistant",
    text: "Your Kyoto plan is drafted across four days. Ask me to rebalance a day, add food stops, or swap anything that does not fit.",
  },
];

export const quickActions = [
  "Make day 3 lighter",
  "Add food stops near the temples",
  "Swap the museum for something outdoors",
  "Rain plan for day 2",
];

export const cannedReplies: { match: RegExp; text: string; chips: string[] }[] = [
  {
    match: /light|slow|relax|less/i,
    text: "Trimmed that day to three stops and pushed the start to 09:30. The temple circuit now has a 90-minute buffer before dinner.",
    chips: ["Removed 1 stop", "Start 09:30", "Buffer +90 min"],
  },
  {
    match: /food|eat|restaurant|dinner|lunch/i,
    text: "Added a counter-seating lunch near your midday cluster and a riverside dinner within a 9-minute walk of your last stop.",
    chips: ["+ Nishiki Market", "+ Pontocho Kappa Sushi"],
  },
  {
    match: /rain|weather/i,
    text: "Rain is forecast for the afternoon. I swapped the garden walk for the covered arcade and kept the evening plan intact.",
    chips: ["Swapped 1 stop", "Weather-aware"],
  },
  {
    match: /swap|replace|instead/i,
    text: "Swapped it for a higher-rated option 400 m away that is open on that day. Travel time between stops dropped by 12 minutes.",
    chips: ["1 swap", "\u221212 min travel"],
  },
];

export const fallbackReply = {
  text: "Updated the plan and rebalanced the timings around it. Ask for anything else and I will keep the rest intact.",
  chips: ["Plan updated"],
};

/* ------------------------------------------------------------------ */
/* Demo traveller profile                                              */
/* ------------------------------------------------------------------ */

export const demoUser = {
  name: "Munish",
  email: "munish@example.com",
};

export const defaultProfile: ProfileState = {
  displayName: "Munish",
  travel: {
    aboutMe:
      "I travel with my partner and our seven-year-old. We like mornings out early, a long lunch, and one unhurried thing in the evening.",
    pace: "balanced",
    stayStyle: "walkable",
    food: ["Vegetarian friendly", "No shellfish"],
    accessibility: ["Stroller friendly"],
    homeCity: "Bengaluru, India",
    currency: "INR",
  },
  travellers: [
    { id: "t1", name: "You", relation: "Primary traveller" },
    { id: "t2", name: "Priya", relation: "Partner", notes: "Prefers slower mornings" },
    { id: "t3", name: "Aarav", relation: "Child", age: "7", notes: "Naps after lunch" },
  ],
  documents: [
    { id: "d1", title: "Passport \u2014 You", kind: "passport", reference: "\u2022\u2022\u2022\u2022 4821", expires: "Mar 2031" },
    { id: "d2", title: "Japan eVisa", kind: "visa", reference: "\u2022\u2022\u2022\u2022 7730", expires: "Nov 2026" },
    { id: "d3", title: "Travel insurance", kind: "insurance", reference: "Policy \u2022\u2022\u2022\u2022 118" },
  ],
  insights: [
    { id: "i1", text: "Prefers walkable neighbourhoods over cheaper stays further out." },
    { id: "i2", text: "Avoids more than two museums in a single day." },
    { id: "i3", text: "Likes one food-market stop per city." },
  ],
  privacy: { personalise: true, rememberPlaces: true, productEmails: false },
};

export const paceOptions = [
  { value: "relaxed", label: "Relaxed", desc: "Two or three things a day, long meals" },
  { value: "balanced", label: "Balanced", desc: "A full but unhurried day" },
  { value: "see_it_all", label: "See it all", desc: "Early starts, packed days" },
] as const;

export const stayOptions = [
  { value: "walkable", label: "Walkable centre", desc: "Pay more, walk everywhere" },
  { value: "quiet", label: "Quiet street", desc: "Calm nights over buzz" },
  { value: "value", label: "Best value", desc: "Happy to commute a little" },
] as const;

export const foodOptions = [
  "Vegetarian friendly",
  "Vegan options",
  "Halal",
  "No shellfish",
  "No pork",
  "Gluten free",
  "Loves street food",
  "Fine dining night",
];

export const accessOptions = [
  "Stroller friendly",
  "Step-free access",
  "Short walks only",
  "Quiet spaces",
];
