import { useCallback, useMemo, useRef, useState } from "react";
import {
  cannedReplies,
  fallbackReply,
  initialMessages,
  placesById,
  trips as seedTrips,
} from "@/fixtures/demoData";
import type { ChatMessage, Day, Stop, Trip } from "@/types";

/**
 * All planner interaction state for the demo. Purely local — no network,
 * no persistence, no backend. The workspace reads it and receives callbacks
 * through typed props.
 */
export interface PlannerState {
  trips: Trip[];
  trip: Trip | undefined;
  day: Day | undefined;
  dayId: string | null;
  selectedPlaceId: string | null;
  hoveredStopId: string | null;
  notice: string | null;
  messages: ChatMessage[];
  thinking: boolean;
  selectTrip: (tripId: string) => void;
  selectDay: (dayId: string) => void;
  selectPlace: (placeId: string | null) => void;
  setHoveredStopId: (stopId: string | null) => void;
  createTrip: (name?: string, destination?: string) => void;
  renameTrip: (tripId: string, name: string) => void;
  moveStop: (dayId: string, from: number, to: number) => void;
  removeStop: (dayId: string, stopId: string) => void;
  addPlaceToDay: (dayId: string, placeId: string) => void;
  addDay: () => void;
  sendMessage: (text: string) => void;
  notify: (message: string) => void;
}

export function usePlannerState(): PlannerState {
  const [trips, setTrips] = useState<Trip[]>(seedTrips);
  const [tripId, setTripId] = useState<string>(seedTrips[0]?.id ?? "");
  const [dayId, setDayId] = useState<string | null>(seedTrips[0]?.days[0]?.id ?? null);
  const [selectedPlaceId, setSelectedPlaceId] = useState<string | null>(
    seedTrips[0]?.days[0]?.stops[0]?.placeId ?? null,
  );
  const [hoveredStopId, setHoveredStopId] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>("All changes saved");
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [thinking, setThinking] = useState(false);

  const counter = useRef(0);
  const nextId = useCallback((prefix: string) => `${prefix}-${++counter.current}`, []);

  const trip = trips.find((t) => t.id === tripId);
  const day = trip?.days.find((d) => d.id === dayId);

  const notify = useCallback((message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice("All changes saved"), 3200);
  }, []);

  const updateDay = useCallback(
    (targetDayId: string, fn: (day: Day) => Day) => {
      setTrips((prev) =>
        prev.map((t) =>
          t.id !== tripId
            ? t
            : { ...t, days: t.days.map((d) => (d.id === targetDayId ? fn(d) : d)) },
        ),
      );
    },
    [tripId],
  );

  const selectTrip = useCallback(
    (id: string) => {
      setTripId(id);
      const target = trips.find((t) => t.id === id);
      const firstDay = target?.days[0];
      setDayId(firstDay?.id ?? null);
      setSelectedPlaceId(firstDay?.stops[0]?.placeId ?? null);
    },
    [trips],
  );

  const selectDay = useCallback(
    (id: string) => {
      setDayId(id);
      const target = trips.find((t) => t.id === tripId)?.days.find((d) => d.id === id);
      setSelectedPlaceId(target?.stops[0]?.placeId ?? null);
    },
    [trips, tripId],
  );

  const createTrip = useCallback(
    (name = "Untitled trip", destination = "Where to?") => {
      const id = nextId("trip");
      const created: Trip = {
        id,
        name,
        destination,
        dateRange: "Dates to set",
        travelers: 1,
        cover: "sage",
        center: [20, 0],
        days: [],
      };
      setTrips((prev) => [created, ...prev]);
      setTripId(id);
      setDayId(null);
      setSelectedPlaceId(null);
      notify("New trip created");
    },
    [nextId, notify],
  );

  const renameTrip = useCallback(
    (id: string, name: string) => {
      setTrips((prev) => prev.map((t) => (t.id === id ? { ...t, name } : t)));
      notify("Trip renamed");
    },
    [notify],
  );

  const moveStop = useCallback(
    (targetDayId: string, from: number, to: number) => {
      updateDay(targetDayId, (d) => {
        const stops = [...d.stops];
        const [moved] = stops.splice(from, 1);
        if (!moved) return d;
        stops.splice(to, 0, moved);
        return { ...d, stops };
      });
      notify("Itinerary reordered · times recalculated");
    },
    [updateDay, notify],
  );

  const removeStop = useCallback(
    (targetDayId: string, stopId: string) => {
      updateDay(targetDayId, (d) => ({ ...d, stops: d.stops.filter((s) => s.id !== stopId) }));
      notify("Stop removed from the day");
    },
    [updateDay, notify],
  );

  const addPlaceToDay = useCallback(
    (targetDayId: string, placeId: string) => {
      const place = placesById[placeId];
      if (!place) return;
      const stop: Stop = {
        id: nextId("stop"),
        placeId,
        startTime: "16:00",
        durationMinutes: place.typicalVisitMinutes,
      };
      updateDay(targetDayId, (d) => ({ ...d, stops: [...d.stops, stop] }));
      notify(`${place.name} added to the day`);
    },
    [nextId, updateDay, notify],
  );

  const addDay = useCallback(() => {
    if (!tripId) return;
    const id = nextId("day");
    setTrips((prev) =>
      prev.map((t) =>
        t.id !== tripId
          ? t
          : {
              ...t,
              days: [
                ...t.days,
                { id, date: "Date to set", title: `Day ${t.days.length + 1}`, stops: [] },
              ],
            },
      ),
    );
    setDayId(id);
    setSelectedPlaceId(null);
    notify("Day added");
  }, [tripId, nextId, notify]);

  const sendMessage = useCallback(
    (text: string) => {
      const trimmed = text.trim();
      if (!trimmed) return;
      setMessages((prev) => [...prev, { id: nextId("m"), role: "user", text: trimmed }]);
      setThinking(true);
      window.setTimeout(() => {
        const reply = cannedReplies.find((r) => r.match.test(trimmed));
        setMessages((prev) => [
          ...prev,
          {
            id: nextId("m"),
            role: "assistant",
            text: reply?.text ?? fallbackReply.text,
            chips: reply?.chips ?? fallbackReply.chips,
          },
        ]);
        setThinking(false);
      }, 900);
    },
    [nextId],
  );

  return useMemo(
    () => ({
      trips,
      trip,
      day,
      dayId,
      selectedPlaceId,
      hoveredStopId,
      notice,
      messages,
      thinking,
      selectTrip,
      selectDay,
      selectPlace: setSelectedPlaceId,
      setHoveredStopId,
      createTrip,
      renameTrip,
      moveStop,
      removeStop,
      addPlaceToDay,
      addDay,
      sendMessage,
      notify,
    }),
    [
      trips,
      trip,
      day,
      dayId,
      selectedPlaceId,
      hoveredStopId,
      notice,
      messages,
      thinking,
      selectTrip,
      selectDay,
      createTrip,
      renameTrip,
      moveStop,
      removeStop,
      addPlaceToDay,
      addDay,
      sendMessage,
      notify,
    ],
  );
}
