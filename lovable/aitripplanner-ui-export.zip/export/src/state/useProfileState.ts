import { useCallback, useMemo, useState } from "react";
import { defaultProfile } from "@/fixtures/demoData";
import type {
  ProfileState,
  TravelDocument,
  TravelProfile,
  Traveller,
} from "@/types";

/** In-memory traveller profile state for the demo (no storage, no backend). */
export interface ProfileController {
  profile: ProfileState;
  update: (patch: Partial<ProfileState>) => void;
  updateTravel: (patch: Partial<TravelProfile>) => void;
  addTraveller: (traveller: Omit<Traveller, "id">) => void;
  removeTraveller: (id: string) => void;
  addDocument: (doc: Omit<TravelDocument, "id">) => void;
  removeDocument: (id: string) => void;
  removeInsight: (id: string) => void;
  clearInsights: () => void;
  resetAll: () => void;
}

let seq = 0;
const uid = (prefix: string) => `${prefix}-${Date.now().toString(36)}-${++seq}`;

export function useProfileState(): ProfileController {
  const [profile, setProfile] = useState<ProfileState>(defaultProfile);

  const mutate = useCallback((fn: (p: ProfileState) => ProfileState) => {
    setProfile((prev) => fn(prev));
  }, []);

  return useMemo(
    () => ({
      profile,
      update: (patch) => mutate((p) => ({ ...p, ...patch })),
      updateTravel: (patch) => mutate((p) => ({ ...p, travel: { ...p.travel, ...patch } })),
      addTraveller: (t) =>
        mutate((p) => ({ ...p, travellers: [...p.travellers, { ...t, id: uid("t") }] })),
      removeTraveller: (id) =>
        mutate((p) => ({ ...p, travellers: p.travellers.filter((t) => t.id !== id) })),
      addDocument: (d) =>
        mutate((p) => ({ ...p, documents: [...p.documents, { ...d, id: uid("d") }] })),
      removeDocument: (id) =>
        mutate((p) => ({ ...p, documents: p.documents.filter((d) => d.id !== id) })),
      removeInsight: (id) =>
        mutate((p) => ({ ...p, insights: p.insights.filter((i) => i.id !== id) })),
      clearInsights: () => mutate((p) => ({ ...p, insights: [] })),
      resetAll: () => setProfile(defaultProfile),
    }),
    [profile, mutate],
  );
}
