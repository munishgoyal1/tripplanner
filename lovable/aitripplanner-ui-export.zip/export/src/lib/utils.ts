import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** "1h 30m" style label for a duration in minutes. */
export function minutesLabel(minutes: number) {
  const h = Math.floor(minutes / 60);
  const r = minutes % 60;
  return h ? `${h}h${r ? ` ${r}m` : ""}` : `${r}m`;
}
