import { useState } from "react";
import {
  ArrowLeft,
  Clock,
  ExternalLink,
  Globe,
  MapPin,
  Phone,
  Plus,
  Repeat,
  Search,
  Star,
  Ticket,
  Timer,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Day, Place, PlaceCategory, Trip } from "@/types";
import { PlaceThumb } from "@/components/shared/PlaceThumb";

const guideFilters: { id: "all" | PlaceCategory; label: string }[] = [
  { id: "all", label: "All" },
  { id: "sight", label: "Sights" },
  { id: "museum", label: "Museums" },
  { id: "food", label: "Food" },
  { id: "nature", label: "Nature" },
  { id: "shopping", label: "Shopping" },
  { id: "nightlife", label: "Nightlife" },
  { id: "stay", label: "Stays" },
];

const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function Stars({ rating, className }: { rating: number; className?: string }) {
  return (
    <span
      className={cn("inline-flex items-center gap-0.5", className)}
      aria-label={`${rating} out of 5`}
    >
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          aria-hidden
          className={cn(
            "h-3.5 w-3.5",
            i <= Math.round(rating) ? "fill-ochre text-ochre" : "text-border",
          )}
        />
      ))}
    </span>
  );
}

export interface DetailsPanelProps {
  /** All searchable demo places. */
  places: Place[];
  place: Place | undefined;
  trip: Trip | undefined;
  day: Day | undefined;
  onSelectPlace: (placeId: string | null) => void;
  onAddPlaceToDay: (dayId: string, placeId: string) => void;
}

export function DetailsPanel({
  places,
  place,
  trip,
  day,
  onSelectPlace,
  onAddPlaceToDay,
}: DetailsPanelProps) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | PlaceCategory>("all");
  const today = dayNames[new Date().getUTCDay()];
  const dayId = day?.id ?? null;

  if (!place) {
    const q = query.trim().toLowerCase();
    const results = places.filter((p) => {
      const matchesQuery =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.city.toLowerCase().includes(q) ||
        p.tags.some((t) => t.toLowerCase().includes(q));
      return matchesQuery && (filter === "all" || p.category === filter);
    });

    return (
      <div className="flex h-full flex-col bg-paper">
        <header className="space-y-2 border-b border-border px-4 py-3">
          <div>
            <h2 className="text-display text-lg">
              {trip?.destination ? `${trip.destination} guide` : "Destination guide"}
            </h2>
            <p className="text-xs text-muted-foreground">
              Search places, then add them straight into a day.
            </p>
          </div>
          <div className="relative">
            <Search
              className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground"
              aria-hidden
            />
            <label className="sr-only" htmlFor="guide-search">
              Search places
            </label>
            <input
              id="guide-search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search sights, food, neighbourhoods"
              className="w-full rounded-md border border-border bg-sand py-2 pl-8 pr-3 text-xs outline-none focus:border-clay/60"
            />
          </div>
          <div className="flex flex-wrap gap-1">
            {guideFilters.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilter(f.id)}
                aria-pressed={filter === f.id}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-[11px] transition-colors",
                  filter === f.id
                    ? "border-clay bg-clay-soft text-foreground"
                    : "border-border text-muted-foreground hover:text-foreground",
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
        </header>

        <div className="flex-1 space-y-1 overflow-y-auto p-2">
          {results.length === 0 && (
            <p className="p-4 text-center text-xs text-muted-foreground">
              Nothing matches that yet — try a broader search.
            </p>
          )}
          {results.map((p) => (
            <div
              key={p.id}
              className="group flex w-full items-center gap-3 rounded-md p-2 hover:bg-accent"
            >
              <button
                type="button"
                onClick={() => onSelectPlace(p.id)}
                className="flex min-w-0 flex-1 items-center gap-3 text-left"
              >
                <PlaceThumb category={p.category} swatch={p.photo} size="sm" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium">{p.name}</span>
                  <span className="block truncate text-[11px] text-muted-foreground">
                    {p.rating} ★ · {p.city} · {p.tags[0]}
                  </span>
                </span>
              </button>
              <button
                type="button"
                disabled={!dayId}
                onClick={() => dayId && onAddPlaceToDay(dayId, p.id)}
                className="rounded-md border border-border p-1.5 text-muted-foreground opacity-0 transition-opacity hover:text-foreground focus-visible:opacity-100 group-hover:opacity-100 disabled:opacity-0"
                aria-label={`Add ${p.name} to the day`}
              >
                <Plus className="h-3.5 w-3.5" aria-hidden />
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const maxBar = Math.max(...place.ratingBreakdown);

  return (
    <div className="flex h-full flex-col overflow-y-auto bg-paper">
      <div className="relative h-36 shrink-0">
        <PlaceThumb
          category={place.category}
          swatch={place.photo}
          size="lg"
          className="rounded-none"
        />
        <span className="absolute left-3 top-3 rounded-full bg-paper/90 px-2 py-0.5 text-[11px] font-medium capitalize shadow-paper">
          {place.category}
        </span>
      </div>

      <div className="border-b border-border px-4 pb-4 pt-3">
        <button
          type="button"
          onClick={() => onSelectPlace(null)}
          className="mb-1.5 inline-flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3 w-3" aria-hidden /> Back to guide
        </button>
        <h2 className="text-display text-xl leading-tight">{place.name}</h2>
        <div className="mt-1.5 flex items-center gap-2 text-xs text-muted-foreground">
          <Stars rating={place.rating} />
          <span className="font-medium text-foreground">{place.rating}</span>
          <span>({place.reviewCount.toLocaleString()} reviews)</span>
          <span aria-hidden>·</span>
          <span>{"¥".repeat(place.priceLevel)}</span>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{place.blurb}</p>

        <div className="mt-3 flex flex-wrap gap-1.5">
          {place.tags.map((t) => (
            <span
              key={t}
              className="rounded-full border border-border bg-secondary px-2 py-0.5 text-[11px] text-secondary-foreground"
            >
              {t}
            </span>
          ))}
        </div>

        <div className="mt-3 flex gap-2">
          <button
            type="button"
            disabled={!dayId}
            onClick={() => dayId && onAddPlaceToDay(dayId, place.id)}
            className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-md bg-clay px-3 py-2 text-xs font-medium text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
          >
            <Plus className="h-3.5 w-3.5" aria-hidden /> Add to{" "}
            {day?.title ? day.title.split(" ")[0] : "day"}
          </button>
          <button
            type="button"
            className="inline-flex items-center justify-center gap-1.5 rounded-md border border-border px-3 py-2 text-xs font-medium hover:bg-accent"
          >
            <Repeat className="h-3.5 w-3.5" aria-hidden /> Replace
          </button>
        </div>
      </div>

      <section className="border-b border-border px-4 py-3">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Ratings
        </h3>
        <div className="mt-2 space-y-1">
          {place.ratingBreakdown.map((pct, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="w-6 text-[11px] tabular-nums text-muted-foreground">{5 - i}★</span>
              <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                <span
                  className="block h-full rounded-full bg-ochre"
                  style={{ width: `${(pct / maxBar) * 100}%` }}
                />
              </span>
              <span className="w-8 text-right text-[11px] tabular-nums text-muted-foreground">
                {pct}%
              </span>
            </div>
          ))}
        </div>
      </section>

      <section className="border-b border-border px-4 py-3">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Visit details
        </h3>
        <dl className="mt-2 space-y-2 text-xs">
          <div className="flex items-start gap-2">
            <Ticket className="mt-0.5 h-3.5 w-3.5 shrink-0 text-clay" aria-hidden />
            <dd>{place.ticket ?? "No ticket required"}</dd>
          </div>
          <div className="flex items-start gap-2">
            <Timer className="mt-0.5 h-3.5 w-3.5 shrink-0 text-clay" aria-hidden />
            <dd>Typical visit {Math.round((place.typicalVisitMinutes / 60) * 10) / 10} h</dd>
          </div>
          <div className="flex items-start gap-2">
            <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-clay" aria-hidden />
            <dd>{place.address}</dd>
          </div>
          {place.phone && (
            <div className="flex items-start gap-2">
              <Phone className="mt-0.5 h-3.5 w-3.5 shrink-0 text-clay" aria-hidden />
              <dd>{place.phone}</dd>
            </div>
          )}
          {place.website && (
            <div className="flex items-start gap-2">
              <Globe className="mt-0.5 h-3.5 w-3.5 shrink-0 text-clay" aria-hidden />
              <dd className="inline-flex items-center gap-1">
                {place.website} <ExternalLink className="h-3 w-3 text-muted-foreground" aria-hidden />
              </dd>
            </div>
          )}
        </dl>
      </section>

      <section className="border-b border-border px-4 py-3">
        <h3 className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          <Clock className="h-3.5 w-3.5" aria-hidden /> Opening hours
        </h3>
        <ul className="mt-2 space-y-1 text-xs">
          {place.hours.map((h) => (
            <li
              key={h.day}
              className={cn(
                "flex justify-between rounded px-1 py-0.5",
                h.day === today && "bg-sage-soft font-medium",
              )}
            >
              <span>{h.day}</span>
              <span className="tabular-nums text-muted-foreground">{h.open}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="px-4 py-3">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Recent reviews
        </h3>
        <ul className="mt-2 space-y-3">
          {place.reviews.map((r) => (
            <li key={r.author} className="rounded-md border border-border p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium">{r.author}</span>
                <span className="text-[11px] text-muted-foreground">{r.date}</span>
              </div>
              <Stars rating={r.rating} className="mt-1" />
              <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{r.text}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
