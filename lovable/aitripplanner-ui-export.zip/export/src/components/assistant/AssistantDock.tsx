import { useEffect, useRef, useState } from "react";
import { Check, ChevronDown, ChevronUp, Loader2, Send, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ChatMessage } from "@/types";

export interface AssistantDockProps {
  messages: ChatMessage[];
  thinking: boolean;
  quickActions: string[];
  onSend: (text: string) => void;
  /** Whether the assistant can fill gaps with smart defaults. */
  smartDefaults?: boolean;
  /** Called when the smart-defaults checkbox is toggled. */
  onSmartDefaultsChange?: (value: boolean) => void;
}

export function AssistantDock({
  messages,
  thinking,
  quickActions,
  onSend,
  smartDefaults: controlledSmartDefaults,
  onSmartDefaultsChange,
}: AssistantDockProps) {
  const [expanded, setExpanded] = useState(false);
  const [value, setValue] = useState("");
  const [internalSmartDefaults, setInternalSmartDefaults] = useState(true);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const smartDefaults = controlledSmartDefaults ?? internalSmartDefaults;
  const setSmartDefaults = (next: boolean) => {
    if (controlledSmartDefaults === undefined) setInternalSmartDefaults(next);
    onSmartDefaultsChange?.(next);
  };

  useEffect(() => {
    if (expanded) scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [messages, expanded]);

  const submit = () => {
    const text = value.trim();
    if (!text) return;
    onSend(text);
    setValue("");
    setExpanded(true);
  };

  return (
    <section
      aria-label="Trip assistant"
      className={cn(
        "flex shrink-0 flex-col border-t border-border bg-paper transition-[height] duration-200",
        expanded ? "h-72" : "h-auto",
      )}
    >
      <div className="flex items-center justify-between px-3 py-1.5">
        <span className="inline-flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          <Sparkles className="h-3.5 w-3.5 text-clay" aria-hidden /> Trip assistant
        </span>
        <button
          type="button"
          onClick={() => setExpanded((e) => !e)}
          aria-expanded={expanded}
          className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] text-muted-foreground hover:bg-accent"
        >
          {expanded ? (
            <>
              Collapse <ChevronDown className="h-3.5 w-3.5" aria-hidden />
            </>
          ) : (
            <>
              History <ChevronUp className="h-3.5 w-3.5" aria-hidden />
            </>
          )}
        </button>
      </div>

      {expanded && (
        <div
          ref={scrollRef}
          role="log"
          aria-live="polite"
          className="flex-1 space-y-3 overflow-y-auto px-3 pb-2"
        >
          {messages.map((m) => (
            <div
              key={m.id}
              className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}
            >
              <div
                className={cn(
                  "max-w-[70%] rounded-lg px-3 py-2 text-sm leading-relaxed",
                  m.role === "user"
                    ? "bg-clay text-primary-foreground"
                    : "border border-border bg-sand",
                )}
              >
                <span className="sr-only">{m.role === "user" ? "You said: " : "Assistant said: "}</span>
                {m.text}
                {m.chips && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {m.chips.map((c) => (
                      <span
                        key={c}
                        className="rounded-full border border-clay/30 bg-paper px-2 py-0.5 text-[11px] text-clay"
                      >
                        {c}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {thinking && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden /> Rebalancing the itinerary…
            </div>
          )}
        </div>
      )}

      <div className="px-3 pb-2">
        <div className="mb-1.5 flex flex-wrap gap-1.5">
          {quickActions.map((q) => (
            <button
              key={q}
              type="button"
              onClick={() => onSend(q)}
              className="rounded-full border border-border px-2.5 py-1 text-[11px] text-muted-foreground transition-colors hover:border-clay/40 hover:text-foreground"
            >
              {q}
            </button>
          ))}
        </div>
        <div className="flex items-end gap-2 rounded-lg border border-border bg-sand px-3 py-2 focus-within:border-clay/50">
          <label className="sr-only" htmlFor="assistant-input">
            Ask the trip assistant
          </label>
          <textarea
            id="assistant-input"
            rows={2}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                submit();
              }
            }}
            placeholder="Ask for a change — “shift dinner later”, “add a market on day 1”…"
            className="max-h-[6rem] flex-1 resize-none bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
          <button
            type="button"
            onClick={submit}
            className="mb-0.5 inline-flex h-8 w-8 items-center justify-center rounded-md bg-clay text-primary-foreground transition-opacity hover:opacity-90"
            aria-label="Send message"
          >
            <Send className="h-4 w-4" aria-hidden />
          </button>
        </div>

        <label className="mt-1.5 inline-flex cursor-pointer select-none items-center gap-2 text-[11px] text-muted-foreground">
          <input
            type="checkbox"
            checked={smartDefaults}
            onChange={(e) => setSmartDefaults(e.target.checked)}
            className="peer sr-only"
          />
          <span
            aria-hidden
            className={cn(
              "inline-flex h-3.5 w-3.5 items-center justify-center rounded-[4px] border transition-colors peer-focus-visible:ring-2 peer-focus-visible:ring-clay/40",
              smartDefaults ? "border-clay bg-clay text-primary-foreground" : "border-border bg-paper",
            )}
          >
            {smartDefaults && <Check className="h-2.5 w-2.5" />}
          </span>
          Let the agent decide with smart defaults
        </label>
      </div>
    </section>
  );
}
