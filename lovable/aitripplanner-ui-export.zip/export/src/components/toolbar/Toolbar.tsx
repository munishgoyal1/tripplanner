import { useState } from "react";
import {
  Check,
  ChevronDown,
  Compass,
  LogOut,
  MapPin,
  Plus,
  Settings,
  Sparkles,
  Star,
  ThumbsDown,
  ThumbsUp,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Trip, WorkspaceView } from "@/types";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const views: { id: WorkspaceView; label: string }[] = [
  { id: "split", label: "Workspace" },
  { id: "plan", label: "Itinerary" },
  { id: "map", label: "Map" },
  { id: "guide", label: "Guide" },
];

export interface ToolbarProps {
  view: WorkspaceView;
  onViewChange: (view: WorkspaceView) => void;
  /** Small saved/status message shown in the middle of the bar. */
  notice: string | null;
  trips: Trip[];
  activeTripId?: string;
  onSelectTrip: (id: string) => void;
  onNewTrip: () => void;
  /** Called for transient status messages from feedback controls. */
  onNotify?: (message: string) => void;
  userName: string;
  userEmail: string;
  onOpenProfile: () => void;
  onSignOut: () => void;
}

export function Toolbar({
  view,
  onViewChange,
  notice,
  trips,
  activeTripId,
  onSelectTrip,
  onNewTrip,
  onNotify,
  userName,
  userEmail,
  onOpenProfile,
  onSignOut,
}: ToolbarProps) {
  const activeTrip = trips.find((t) => t.id === activeTripId);

  return (
    <header className="flex h-12 shrink-0 items-center gap-3 border-b border-border bg-paper px-3">
      <span className="inline-flex items-center gap-2">
        <Compass className="h-4 w-4 text-clay" aria-hidden />
        <span className="text-display text-base">AI Trip Planner</span>
      </span>

      <DropdownMenu>
        <DropdownMenuTrigger className="flex max-w-[230px] items-center gap-2 rounded-full border border-border bg-sand px-3 py-1.5 text-xs hover:bg-accent">
          <MapPin className="h-3.5 w-3.5 shrink-0 text-clay" aria-hidden />
          <span className="truncate font-medium">{activeTrip?.name ?? "No trip"}</span>
          <span className="shrink-0 text-muted-foreground">({trips.length})</span>
          <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-hidden />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-72">
          <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">
            Your trips
          </DropdownMenuLabel>
          {trips.map((t) => (
            <DropdownMenuItem
              key={t.id}
              onSelect={() => onSelectTrip(t.id)}
              className="flex items-start gap-2 text-xs"
            >
              <Check
                className={cn(
                  "mt-0.5 h-3.5 w-3.5 shrink-0 text-sage",
                  t.id === activeTripId ? "opacity-100" : "opacity-0",
                )}
                aria-hidden
              />
              <span className="min-w-0">
                <span className="block truncate font-medium">{t.name}</span>
                <span className="block truncate text-[11px] text-muted-foreground">
                  {t.destination} · {t.dateRange}
                </span>
              </span>
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={onNewTrip} className="gap-2 text-xs">
            <Plus className="h-3.5 w-3.5 text-clay" aria-hidden /> New trip
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <div
        className="hidden items-center gap-0.5 rounded-full border border-border bg-sand p-0.5 md:flex"
        role="tablist"
        aria-label="Workspace view"
      >
        {views.map((v) => (
          <button
            key={v.id}
            type="button"
            role="tab"
            aria-selected={view === v.id}
            onClick={() => onViewChange(v.id)}
            className={cn(
              "rounded-full px-3 py-1 text-xs transition-colors",
              view === v.id
                ? "bg-paper font-medium text-foreground shadow-paper"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            {v.label}
          </button>
        ))}
      </div>

      <div className="flex flex-1 justify-center">
        {notice && (
          <span
            aria-live="polite"
            className="inline-flex items-center gap-1.5 rounded-full border border-border bg-sand px-3 py-1 text-[11px] text-muted-foreground"
          >
            <Check className="h-3 w-3 text-sage" aria-hidden />
            {notice}
          </span>
        )}
      </div>

      <TripFeedback onNotify={onNotify} />

      <button
        type="button"
        onClick={onNewTrip}
        className="hidden items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-xs font-medium hover:bg-accent sm:inline-flex"
      >
        <Plus className="h-3.5 w-3.5 text-clay" aria-hidden /> New trip
      </button>

      <DropdownMenu>
        <DropdownMenuTrigger className="flex items-center gap-2 rounded-full border border-border py-1 pl-1 pr-3 text-xs hover:bg-accent">
          <span
            className="flex h-6 w-6 items-center justify-center rounded-full bg-clay text-[11px] font-semibold uppercase text-primary-foreground"
            aria-hidden
          >
            {userName.slice(0, 1)}
          </span>
          <span className="max-w-[6rem] truncate">{userName}</span>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">
            {userEmail}
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={onOpenProfile} className="gap-2 text-xs">
            <Settings className="h-3.5 w-3.5" aria-hidden /> Profile &amp; settings
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={onOpenProfile} className="gap-2 text-xs">
            <Sparkles className="h-3.5 w-3.5" aria-hidden /> Travel profile
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={onSignOut} className="gap-2 text-xs">
            <LogOut className="h-3.5 w-3.5" aria-hidden /> Sign out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}

/** Lightweight feedback on the current plan: helpful / not helpful, plus a rating. */
function TripFeedback({ onNotify }: { onNotify?: (message: string) => void }) {
  const [vote, setVote] = useState<"up" | "down" | null>(null);
  const [rating, setRating] = useState<number | null>(null);

  return (
    <div className="hidden items-center gap-0.5 rounded-full border border-border bg-sand p-0.5 lg:flex">
      <button
        type="button"
        onClick={() => {
          setVote("up");
          onNotify?.("Thanks — noted that this plan works");
        }}
        aria-label="This plan is helpful"
        aria-pressed={vote === "up"}
        className={cn(
          "rounded-full p-1.5 transition-colors hover:bg-paper",
          vote === "up" ? "bg-paper text-sage" : "text-muted-foreground",
        )}
      >
        <ThumbsUp className="h-3.5 w-3.5" aria-hidden />
      </button>
      <button
        type="button"
        onClick={() => {
          setVote("down");
          onNotify?.("Thanks — I'll suggest alternatives");
        }}
        aria-label="This plan needs work"
        aria-pressed={vote === "down"}
        className={cn(
          "rounded-full p-1.5 transition-colors hover:bg-paper",
          vote === "down" ? "bg-paper text-clay" : "text-muted-foreground",
        )}
      >
        <ThumbsDown className="h-3.5 w-3.5" aria-hidden />
      </button>
      <DropdownMenu>
        <DropdownMenuTrigger
          type="button"
          className="inline-flex items-center gap-1 rounded-full px-2 py-1 text-[11px] text-muted-foreground hover:bg-paper hover:text-foreground"
          aria-label="Rate this trip plan"
        >
          <Star
            className={cn("h-3.5 w-3.5", rating ? "fill-ochre text-ochre" : "text-muted-foreground")}
            aria-hidden
          />
          {rating ? `${rating}/5` : "Rate"}
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">
            Rate this trip plan
          </DropdownMenuLabel>
          {[5, 4, 3, 2, 1].map((n) => (
            <DropdownMenuItem
              key={n}
              onSelect={() => {
                setRating(n);
                onNotify?.(`Rated this plan ${n} out of 5`);
              }}
              className="gap-1 text-xs"
            >
              {Array.from({ length: n }).map((_, i) => (
                <Star key={i} className="h-3.5 w-3.5 fill-ochre text-ochre" aria-hidden />
              ))}
              <span className="ml-1 text-muted-foreground">{n}</span>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
