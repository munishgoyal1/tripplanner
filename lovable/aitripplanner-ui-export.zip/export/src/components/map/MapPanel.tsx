import { useEffect, useRef, useState } from "react";
import type * as LeafletNS from "leaflet";
import { Crosshair, Layers, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Day, Place, Trip } from "@/types";

export interface MapPanelProps {
  trip: Trip | undefined;
  day: Day | undefined;
  placesById: Record<string, Place>;
  selectedDayId: string | null;
  selectedPlaceId: string | null;
  hoveredStopId: string | null;
  onSelectDay: (dayId: string) => void;
  onSelectPlace: (placeId: string) => void;
}

export function MapPanel({
  trip,
  day,
  placesById,
  selectedDayId,
  selectedPlaceId,
  hoveredStopId,
  onSelectDay,
  onSelectPlace,
}: MapPanelProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<LeafletNS.Map | null>(null);
  const layerRef = useRef<LeafletNS.LayerGroup | null>(null);
  const leafletRef = useRef<typeof LeafletNS | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const [{ default: L }] = await Promise.all([
        import("leaflet"),
        import("leaflet/dist/leaflet.css"),
      ]);
      if (cancelled || !containerRef.current || mapRef.current) return;
      leafletRef.current = L;
      const map = L.map(containerRef.current, {
        zoomControl: true,
        attributionControl: true,
        scrollWheelZoom: true,
      }).setView([34.999, 135.768], 12);
      L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
        attribution: "&copy; OpenStreetMap &copy; CARTO",
        maxZoom: 19,
      }).addTo(map);
      layerRef.current = L.layerGroup().addTo(map);
      mapRef.current = map;
      setReady(true);
    })();
    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  // Redraw markers whenever the selected day, trip or selection changes.
  useEffect(() => {
    const L = leafletRef.current;
    const map = mapRef.current;
    const layer = layerRef.current;
    if (!ready || !L || !map || !layer) return;
    layer.clearLayers();

    const stops = day?.stops ?? [];
    const coords: [number, number][] = [];

    stops.forEach((stop, i) => {
      const place = placesById[stop.placeId];
      if (!place) return;
      const active = place.id === selectedPlaceId || stop.id === hoveredStopId;
      coords.push([place.lat, place.lng]);
      const marker = L.marker([place.lat, place.lng], {
        icon: L.divIcon({
          className: "",
          html: `<div class="planner-pin${active ? " planner-pin-active" : ""}">${i + 1}</div>`,
          iconSize: [30, 30],
          iconAnchor: [15, 15],
        }),
        alt: place.name,
      });
      marker.on("click", () => onSelectPlace(place.id));
      marker.bindTooltip(place.name, { direction: "top", offset: [0, -14] });
      marker.addTo(layer);
    });

    if (coords.length > 1) {
      L.polyline(coords, {
        color: "#9c5a3c",
        weight: 2,
        opacity: 0.7,
        dashArray: "6 6",
      }).addTo(layer);
    }

    if (coords.length > 0) {
      map.fitBounds(L.latLngBounds(coords).pad(0.35), { animate: true });
    } else if (trip) {
      map.setView(trip.center, 11);
    }
  }, [ready, day, trip, placesById, selectedPlaceId, hoveredStopId, onSelectPlace]);

  const fitToDay = () => {
    const L = leafletRef.current;
    const map = mapRef.current;
    if (!L || !map) return;
    const coords = (day?.stops ?? [])
      .map((s) => placesById[s.placeId])
      .filter((p): p is Place => Boolean(p))
      .map((p) => [p.lat, p.lng] as [number, number]);
    if (coords.length) map.fitBounds(L.latLngBounds(coords).pad(0.35));
  };

  return (
    <div className="relative h-full w-full overflow-hidden">
      <div ref={containerRef} className="h-full w-full" role="application" aria-label="Trip map" />

      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center bg-sand">
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" aria-hidden />
          <span className="sr-only">Loading map</span>
        </div>
      )}

      {/* Day filter chips */}
      <div className="pointer-events-auto absolute left-14 top-3 z-[500] flex flex-wrap gap-1.5">
        {trip?.days.map((d, i) => (
          <button
            key={d.id}
            type="button"
            onClick={() => onSelectDay(d.id)}
            aria-pressed={d.id === selectedDayId}
            className={cn(
              "rounded-full border px-3 py-1 text-xs font-medium shadow-paper transition-colors",
              d.id === selectedDayId
                ? "border-clay bg-clay text-primary-foreground"
                : "border-border bg-paper/90 text-muted-foreground hover:text-foreground",
            )}
          >
            Day {i + 1}
          </button>
        ))}
      </div>

      <div className="absolute bottom-4 left-3 z-[500] flex gap-1.5">
        <button
          type="button"
          onClick={fitToDay}
          className="inline-flex items-center gap-1.5 rounded-full border border-border bg-paper/90 px-3 py-1.5 text-xs font-medium shadow-paper hover:bg-accent"
        >
          <Crosshair className="h-3.5 w-3.5" aria-hidden /> Fit to day
        </button>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-paper/90 px-3 py-1.5 text-xs text-muted-foreground shadow-paper">
          <Layers className="h-3.5 w-3.5" aria-hidden /> {day?.stops.length ?? 0} stops
        </span>
      </div>
    </div>
  );
}
