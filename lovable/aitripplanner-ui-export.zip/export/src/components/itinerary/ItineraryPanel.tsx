import { useState } from "react";
import {
  ChevronDown,
  Clock,
  Footprints,
  GripVertical,
  Plus,
  Train,
  Trash2,
  Wallet,
} from "lucide-react";
import { cn, minutesLabel } from "@/lib/utils";
import type { Place, Trip } from "@/types";
import { CategoryIcon } from "@/components/shared/PlaceThumb";
import { TripSnapshot } from "./TripSnapshot";

export interface ItineraryPanelProps {
  trip: Trip | undefined;
  placesById: Record<string, Place>;
  selectedDayId: string | null;
  selectedPlaceId: string | null;
  documentCount: number;
  onSelectDay: (dayId: string) => void;
  onSelectPlace: (placeId: string | null) => void;
  onHoverStop: (stopId: string | null) => void;
  onMoveStop: (dayId: string, from: number, to: number) => void;
  onRemoveStop: (dayId: string, stopId: string) => void;
  onRenameTrip: (tripId: string, name: string) => void;
  onAddDay: () => void;
}

export function ItineraryPanel({
  trip,
  placesById,
  selectedDayId,
  selectedPlaceId,
  documentCount,
  onSelectDay,
  onSelectPlace,
  onHoverStop,
  onMoveStop,
  onRemoveStop,
  onRenameTrip,
  onAddDay,
}: ItineraryPanelProps) {
  const [dragIndex, setDragIndex] = useState<number | null>(null);

  if (!trip) {
    return (
      <div className="flex h-full items-center justify-center bg-sidebar p-6 text-center text-sm text-muted-foreground">
        No trip open yet.
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col bg-sidebar">
      <TripSnapshot
        trip={trip}
        placesById={placesById}
        documentCount={documentCount}
        onRenameTrip={onRenameTrip}
      />

      <div className="flex-1 overflow-y-auto px-2 pb-6">
        {trip.days.length === 0 ? (
          <div className="mx-2 mt-4 rounded-lg border border-dashed border-border p-5 text-center">
            <p className="text-display text-lg">A blank canvas</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Describe the trip in the chat below and the first draft appears here.
            </p>
          </div>
        ) : (
          trip.days.map((day, dayIdx) => {
            const open = day.id === selectedDayId;
            const total = day.stops.reduce(
              (acc, s) => acc + s.durationMinutes + (s.travelToNextMinutes ?? 0),
              0,
            );
            const travel = day.stops.reduce((acc, s) => acc + (s.travelToNextMinutes ?? 0), 0);

            return (
              <section key={day.id} className="mt-2">
                <button
                  type="button"
                  onClick={() => onSelectDay(day.id)}
                  aria-expanded={open}
                  className={cn(
                    "flex w-full items-center gap-2 rounded-md px-2 py-2 text-left transition-colors",
                    open ? "bg-accent" : "hover:bg-accent/60",
                  )}
                >
                  <span
                    className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-clay text-[11px] font-semibold text-primary-foreground"
                    aria-hidden
                  >
                    {dayIdx + 1}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium">{day.title}</span>
                    <span className="block text-[11px] text-muted-foreground">{day.date}</span>
                  </span>
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 shrink-0 text-muted-foreground transition-transform",
                      open && "rotate-180",
                    )}
                    aria-hidden
                  />
                </button>

                {open && (
                  <ol className="mt-1 space-y-1 pl-2">
                    {day.stops.map((stop, i) => {
                      const place = placesById[stop.placeId];
                      if (!place) return null;
                      const active = place.id === selectedPlaceId;
                      return (
                        <li key={stop.id}>
                          <div
                            draggable
                            onDragStart={() => setDragIndex(i)}
                            onDragOver={(e) => e.preventDefault()}
                            onDrop={() => {
                              if (dragIndex !== null && dragIndex !== i)
                                onMoveStop(day.id, dragIndex, i);
                              setDragIndex(null);
                            }}
                            onMouseEnter={() => onHoverStop(stop.id)}
                            onMouseLeave={() => onHoverStop(null)}
                            className={cn(
                              "group flex items-start gap-2 rounded-md border px-2 py-2 transition-colors",
                              active
                                ? "border-clay/40 bg-paper shadow-paper"
                                : "border-transparent hover:border-border hover:bg-paper/70",
                            )}
                          >
                            <GripVertical
                              className="mt-0.5 h-4 w-4 shrink-0 cursor-grab text-muted-foreground/50 opacity-0 transition-opacity group-hover:opacity-100"
                              aria-hidden
                            />
                            <button
                              type="button"
                              onClick={() => onSelectPlace(place.id)}
                              onFocus={() => onHoverStop(stop.id)}
                              onBlur={() => onHoverStop(null)}
                              aria-current={active ? "true" : undefined}
                              className="min-w-0 flex-1 text-left"
                            >
                              <span className="flex items-center gap-1.5 text-[11px] tabular-nums text-muted-foreground">
                                <Clock className="h-3 w-3" aria-hidden />
                                {stop.startTime}
                                <span aria-hidden>·</span>
                                {minutesLabel(stop.durationMinutes)}
                              </span>
                              <span className="mt-0.5 flex items-center gap-1.5">
                                <CategoryIcon
                                  category={place.category}
                                  className="h-3.5 w-3.5 shrink-0 text-clay"
                                />
                                <span className="truncate text-sm font-medium">{place.name}</span>
                              </span>
                              {stop.note && (
                                <span className="mt-1 line-clamp-2 block text-[11px] italic text-muted-foreground">
                                  {stop.note}
                                </span>
                              )}
                            </button>
                            <button
                              type="button"
                              onClick={() => onRemoveStop(day.id, stop.id)}
                              className="mt-0.5 rounded p-1 text-muted-foreground/60 opacity-0 transition-opacity hover:bg-destructive/10 hover:text-destructive focus-visible:opacity-100 group-hover:opacity-100"
                              aria-label={`Remove ${place.name}`}
                            >
                              <Trash2 className="h-3.5 w-3.5" aria-hidden />
                            </button>
                          </div>

                          {stop.travelToNextMinutes ? (
                            <div className="ml-6 flex items-center gap-1.5 py-1 text-[11px] text-muted-foreground">
                              {stop.travelMode === "metro" ? (
                                <Train className="h-3 w-3" aria-hidden />
                              ) : (
                                <Footprints className="h-3 w-3" aria-hidden />
                              )}
                              {stop.travelToNextMinutes} min{" "}
                              {stop.travelMode === "metro" ? "by train" : "walk"}
                            </div>
                          ) : null}
                        </li>
                      );
                    })}

                    <li className="flex items-center justify-between rounded-md bg-accent/50 px-2 py-1.5 text-[11px] text-muted-foreground">
                      <span className="inline-flex items-center gap-1.5">
                        <Clock className="h-3 w-3" aria-hidden /> {minutesLabel(total)} planned ·{" "}
                        {minutesLabel(travel)} moving
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <Wallet className="h-3 w-3" aria-hidden /> ~¥
                        {(day.stops.length * 1400).toLocaleString()}
                      </span>
                    </li>
                  </ol>
                )}
              </section>
            );
          })
        )}

        <button
          type="button"
          onClick={onAddDay}
          className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-border px-2 py-2 text-xs text-muted-foreground transition-colors hover:border-clay/50 hover:text-foreground"
        >
          <Plus className="h-3.5 w-3.5" aria-hidden /> Add a day
        </button>
      </div>
    </div>
  );
}
