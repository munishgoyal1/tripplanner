import { CalendarDays, Check, MapPin, Pencil, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Place, Trip } from "@/types";

export interface TripSnapshotProps {
  trip: Trip;
  placesById: Record<string, Place>;
  /** Number of stored travel documents — drives the "Documents ready" check. */
  documentCount: number;
  onRenameTrip: (tripId: string, name: string) => void;
}

export function TripSnapshot({
  trip,
  placesById,
  documentCount,
  onRenameTrip,
}: TripSnapshotProps) {
  const stops = trip.days.reduce((a, d) => a + d.stops.length, 0);

  const checks = [
    { label: "Dates set", done: trip.dateRange !== "Dates to set" },
    {
      label: "Every day planned",
      done: trip.days.length > 0 && trip.days.every((d) => d.stops.length > 0),
    },
    {
      label: "Meals covered",
      done: trip.days.every(
        (d) =>
          d.stops.length === 0 || d.stops.some((s) => placesById[s.placeId]?.category === "food"),
      ),
    },
    {
      label: "Stay booked",
      done: trip.days.some((d) => d.stops.some((s) => placesById[s.placeId]?.category === "stay")),
    },
    { label: "Documents ready", done: documentCount >= 2 },
  ];
  const done = checks.filter((c) => c.done).length;
  const pct = Math.round((done / checks.length) * 100);

  return (
    <div className="border-b border-sidebar-border px-3 py-3">
      <div className="flex items-start gap-2">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <h2 className="truncate text-display text-lg leading-tight">{trip.name}</h2>
            <button
              type="button"
              onClick={() => {
                const name = window.prompt("Rename trip", trip.name);
                if (name) onRenameTrip(trip.id, name);
              }}
              className="rounded p-1 text-muted-foreground hover:bg-accent hover:text-foreground"
              aria-label="Rename trip"
            >
              <Pencil className="h-3 w-3" aria-hidden />
            </button>
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
            <span className="inline-flex items-center gap-1 truncate">
              <MapPin className="h-3 w-3" aria-hidden /> {trip.destination}
            </span>
            <span className="inline-flex items-center gap-1">
              <CalendarDays className="h-3 w-3" aria-hidden /> {trip.dateRange}
            </span>
            <span className="inline-flex items-center gap-1">
              <Users className="h-3 w-3" aria-hidden /> {trip.travelers}
            </span>
          </div>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        {(
          [
            ["Days", trip.days.length],
            ["Stops", stops],
            ["Ready", `${pct}%`],
          ] as const
        ).map(([label, value]) => (
          <div key={label} className="rounded-md border border-border bg-paper py-1.5">
            <div className="text-sm font-semibold tabular-nums">{value}</div>
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
          </div>
        ))}
      </div>

      <div className="mt-3">
        <div
          className="h-1.5 overflow-hidden rounded-full bg-secondary"
          role="progressbar"
          aria-valuenow={pct}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Trip readiness"
        >
          <div className="h-full rounded-full bg-sage transition-all" style={{ width: `${pct}%` }} />
        </div>
        <ul className="mt-2 flex flex-wrap gap-x-3 gap-y-1">
          {checks.map((c) => (
            <li
              key={c.label}
              className={cn(
                "inline-flex items-center gap-1 text-[11px]",
                c.done ? "text-muted-foreground" : "text-foreground",
              )}
            >
              <span
                className={cn(
                  "flex h-3.5 w-3.5 items-center justify-center rounded-full border",
                  c.done ? "border-sage bg-sage-soft" : "border-dashed border-border",
                )}
                aria-hidden
              >
                {c.done && <Check className="h-2.5 w-2.5 text-sage" />}
              </span>
              {c.label}
              <span className="sr-only">{c.done ? " — done" : " — outstanding"}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
