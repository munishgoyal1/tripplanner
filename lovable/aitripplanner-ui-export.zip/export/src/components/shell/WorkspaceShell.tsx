import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import type { WorkspaceView } from "@/types";

export interface WorkspaceShellProps {
  view: WorkspaceView;
  banner?: ReactNode;
  toolbar: ReactNode;
  warnings: ReactNode;
  itinerary: ReactNode;
  map: ReactNode;
  details: ReactNode;
  assistant: ReactNode;
  mobileBar: ReactNode;
  overlay?: ReactNode;
}

/** Full-height workspace layout: optional banner, toolbar, warnings, three panels, assistant dock. */
export function WorkspaceShell({
  view,
  banner,
  toolbar,
  warnings,
  itinerary,
  map,
  details,
  assistant,
  mobileBar,
  overlay,
}: WorkspaceShellProps) {
  const showRail = view === "split" || view === "plan";
  const showMap = view === "split" || view === "map";
  const showGuide = view === "split" || view === "guide";

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-sand">
      {banner}
      {toolbar}
      {warnings}

      <main className="flex min-h-0 flex-1">
        {showRail && (
          <aside
            aria-label="Itinerary"
            className={cn(
              "shrink-0 border-r border-border",
              view === "plan" ? "w-full" : "hidden w-[300px] md:block xl:w-[340px]",
            )}
          >
            {itinerary}
          </aside>
        )}

        {showMap && (
          <div
            className={cn(
              "relative z-0 min-w-0 flex-1",
              view === "split" && "hidden md:block",
            )}
          >
            {map}
          </div>
        )}

        {showGuide && (
          <aside
            aria-label="Place guide"
            className={cn(
              "shrink-0 border-l border-border",
              view === "guide" ? "w-full" : "hidden w-[360px] lg:block xl:w-[400px]",
            )}
          >
            {details}
          </aside>
        )}
      </main>

      {assistant}
      {mobileBar}
      {overlay}
    </div>
  );
}
