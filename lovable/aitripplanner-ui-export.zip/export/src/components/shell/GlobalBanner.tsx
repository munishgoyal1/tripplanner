import { useState } from "react";
import { Megaphone, X } from "lucide-react";

export interface GlobalBannerProps {
  message?: string;
  actionLabel?: string;
  onAction?: () => void;
  defaultOpen?: boolean;
}

/** Slim global announcement row shown above the workspace. */
export function GlobalBanner({
  message = "New: the assistant can now book-check hotels and flag price drops while you plan.",
  actionLabel = "See what's new",
  onAction,
  defaultOpen = true,
}: GlobalBannerProps) {
  const [open, setOpen] = useState(defaultOpen);
  if (!open) return null;

  return (
    <div className="flex h-9 shrink-0 items-center gap-2 border-b border-ochre/30 bg-ochre/10 px-3 text-xs">
      <Megaphone className="h-3.5 w-3.5 shrink-0 text-ochre" aria-hidden />
      <p className="min-w-0 flex-1 truncate text-foreground">{message}</p>
      {onAction && (
        <button
          type="button"
          onClick={onAction}
          className="hidden shrink-0 rounded-full border border-ochre/40 bg-paper px-2.5 py-0.5 text-[11px] font-medium hover:bg-accent sm:inline-flex"
        >
          {actionLabel}
        </button>
      )}
      <button
        type="button"
        onClick={() => setOpen(false)}
        aria-label="Dismiss announcement"
        className="shrink-0 rounded p-1 text-muted-foreground hover:bg-paper hover:text-foreground"
      >
        <X className="h-3.5 w-3.5" aria-hidden />
      </button>
    </div>
  );
}
