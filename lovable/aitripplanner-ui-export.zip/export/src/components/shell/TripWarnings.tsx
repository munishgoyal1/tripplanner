import { useMemo, useState } from "react";
import { AlertTriangle, ArrowRight, X } from "lucide-react";
import type { Place, Trip } from "@/types";

interface Gap {
  id: string;
  text: string;
  action: string;
}

export interface TripWarningsProps {
  trip: Trip | undefined;
  placesById: Record<string, Place>;
  /** Sends the suggested fix to the assistant. */
  onAction: (action: string) => void;
}

export function TripWarnings({ trip, placesById, onAction }: TripWarningsProps) {
  const [dismissed, setDismissed] = useState<string[]>([]);

  const gaps = useMemo<Gap[]>(() => {
    if (!trip) return [];
    const list: Gap[] = [];

    if (trip.dateRange === "Dates to set") {
      list.push({ id: "dates", text: "This trip has no dates yet.", action: "Set dates" });
    }

    const emptyDay = trip.days.find((d) => d.stops.length === 0);
    if (emptyDay) {
      list.push({
        id: `empty-${emptyDay.id}`,
        text: `${emptyDay.title} has nothing planned.`,
        action: "Fill this day",
      });
    }

    const noFoodDay = trip.days.find(
      (d) => d.stops.length > 2 && !d.stops.some((s) => placesById[s.placeId]?.category === "food"),
    );
    if (noFoodDay) {
      list.push({
        id: `food-${noFoodDay.id}`,
        text: `No meal stop on ${noFoodDay.title}.`,
        action: "Add food stops",
      });
    }

    const heavyDay = trip.days.find((d) => d.stops.length >= 5);
    if (heavyDay) {
      list.push({
        id: `heavy-${heavyDay.id}`,
        text: `${heavyDay.title} looks packed — ${heavyDay.stops.length} stops.`,
        action: "Make it lighter",
      });
    }

    const noStay = !trip.days.some((d) =>
      d.stops.some((s) => placesById[s.placeId]?.category === "stay"),
    );
    if (noStay) {
      list.push({
        id: "stay",
        text: "No accommodation saved for this trip.",
        action: "Suggest stays",
      });
    }

    return list;
  }, [trip, placesById]);

  const visible = gaps.filter((g) => !dismissed.includes(g.id));
  const gap = visible[0];
  if (!gap) return null;

  return (
    <div
      role="status"
      className="flex shrink-0 items-center gap-3 border-b border-ochre/40 bg-ochre/15 px-3 py-1.5 text-xs"
    >
      <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-ochre" aria-hidden />
      <span className="min-w-0 flex-1 truncate">{gap.text}</span>
      {visible.length > 1 && (
        <span className="hidden rounded-full bg-paper px-2 py-0.5 text-[10px] text-muted-foreground sm:inline">
          +{visible.length - 1} more
        </span>
      )}
      <button
        type="button"
        onClick={() => {
          onAction(gap.action);
          setDismissed((d) => [...d, gap.id]);
        }}
        className="inline-flex items-center gap-1 rounded-full bg-clay px-2.5 py-1 font-medium text-primary-foreground hover:opacity-90"
      >
        {gap.action} <ArrowRight className="h-3 w-3" aria-hidden />
      </button>
      <button
        type="button"
        onClick={() => setDismissed((d) => [...d, gap.id])}
        className="rounded p-1 text-muted-foreground hover:text-foreground"
        aria-label="Dismiss warning"
      >
        <X className="h-3.5 w-3.5" aria-hidden />
      </button>
    </div>
  );
}
