import { CalendarDays, Compass, Map as MapIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import type { WorkspaceView } from "@/types";

const tabs: { id: WorkspaceView; label: string; icon: typeof MapIcon }[] = [
  { id: "plan", label: "Itinerary", icon: CalendarDays },
  { id: "map", label: "Map", icon: MapIcon },
  { id: "guide", label: "Guide", icon: Compass },
];

export interface MobileViewBarProps {
  view: WorkspaceView;
  onViewChange: (view: WorkspaceView) => void;
}

/** Small-screen switcher between the itinerary, map and guide panels. */
export function MobileViewBar({ view, onViewChange }: MobileViewBarProps) {
  return (
    <nav
      aria-label="Workspace panels"
      className="flex shrink-0 items-stretch border-t border-border bg-paper md:hidden"
    >
      {tabs.map((t) => {
        const active = view === t.id || (view === "split" && t.id === "plan");
        return (
          <button
            key={t.id}
            type="button"
            onClick={() => onViewChange(t.id)}
            aria-current={active ? "page" : undefined}
            className={cn(
              "flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] transition-colors",
              active ? "text-clay" : "text-muted-foreground hover:text-foreground",
            )}
          >
            <t.icon className="h-4 w-4" aria-hidden />
            {t.label}
          </button>
        );
      })}
    </nav>
  );
}
