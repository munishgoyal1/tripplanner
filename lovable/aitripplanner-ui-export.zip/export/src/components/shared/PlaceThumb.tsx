import {
  BedDouble,
  Camera,
  Landmark,
  Leaf,
  Moon,
  ShoppingBag,
  Train,
  Utensils,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { PlaceCategory } from "@/types";

const icons: Record<PlaceCategory, typeof Landmark> = {
  sight: Landmark,
  museum: Camera,
  food: Utensils,
  nature: Leaf,
  shopping: ShoppingBag,
  nightlife: Moon,
  stay: BedDouble,
  transit: Train,
};

const swatches: Record<string, string> = {
  clay: "from-clay-soft to-clay/70",
  sage: "from-sage-soft to-sage/70",
  ochre: "from-accent to-ochre/70",
};

export interface CategoryIconProps {
  category: PlaceCategory;
  className?: string;
}

export function CategoryIcon({ category, className }: CategoryIconProps) {
  const Icon = icons[category] ?? Landmark;
  return <Icon className={cn("h-4 w-4", className)} aria-hidden />;
}

export interface PlaceThumbProps {
  category: PlaceCategory;
  /** Colour swatch key from the fixture data: clay | sage | ochre. */
  swatch?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function PlaceThumb({ category, swatch = "clay", size = "md", className }: PlaceThumbProps) {
  return (
    <div
      className={cn(
        "grain relative flex items-center justify-center overflow-hidden rounded-md bg-gradient-to-br text-clay",
        swatches[swatch] ?? swatches["clay"],
        size === "sm" && "h-9 w-9",
        size === "md" && "h-14 w-14",
        size === "lg" && "h-full w-full rounded-lg",
        className,
      )}
      aria-hidden
    >
      <CategoryIcon
        category={category}
        className={cn(
          size === "lg" ? "h-8 w-8" : size === "md" ? "h-5 w-5" : "h-4 w-4",
          "opacity-70",
        )}
      />
    </div>
  );
}
