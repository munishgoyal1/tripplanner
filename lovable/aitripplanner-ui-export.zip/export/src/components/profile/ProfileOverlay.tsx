import { useState, type ReactNode } from "react";
import {
  BarChart3,
  FileText,
  Fingerprint,
  Plus,
  Shield,
  Sparkles,
  Trash2,
  Users,
  X,
} from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { accessOptions, foodOptions, paceOptions, stayOptions } from "@/fixtures/demoData";
import { cn } from "@/lib/utils";
import type { ProfileController } from "@/state/useProfileState";
import type { Trip } from "@/types";

export type ProfileSectionId =
  | "identity"
  | "travel"
  | "travellers"
  | "documents"
  | "analytics"
  | "privacy";

const sections: { id: ProfileSectionId; label: string; icon: typeof Fingerprint; hint: string }[] = [
  { id: "identity", label: "Profile & sign-in", icon: Fingerprint, hint: "Name, email, account" },
  { id: "travel", label: "Travel profile", icon: Sparkles, hint: "How you like to travel" },
  { id: "travellers", label: "Travellers", icon: Users, hint: "Who is coming along" },
  { id: "documents", label: "Documents", icon: FileText, hint: "Passports, visas, bookings" },
  { id: "analytics", label: "Trip analytics", icon: BarChart3, hint: "Your planning patterns" },
  { id: "privacy", label: "Privacy & data", icon: Shield, hint: "What we remember" },
];

function SectionTitle({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="mb-5">
      <h2 className="text-display text-2xl">{title}</h2>
      <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
    </div>
  );
}

function Chip({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "rounded-full border px-3 py-1.5 text-xs transition-colors",
        active
          ? "border-clay bg-clay-soft text-foreground"
          : "border-border bg-paper text-muted-foreground hover:border-clay/40 hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}

function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("panel p-4", className)}>{children}</div>;
}

export interface ProfileOverlayProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialSection?: ProfileSectionId;
  /** In-memory profile data plus its mutators. */
  controller: ProfileController;
  userName: string;
  userEmail: string;
  trip: Trip | undefined;
  onSignOut: () => void;
  onNotify: (message: string) => void;
}

export function ProfileOverlay({
  open,
  onOpenChange,
  initialSection = "identity",
  controller,
  userName,
  userEmail,
  trip,
  onSignOut,
  onNotify,
}: ProfileOverlayProps) {
  const [section, setSection] = useState<ProfileSectionId>(initialSection);
  const {
    profile,
    update,
    updateTravel,
    addTraveller,
    removeTraveller,
    addDocument,
    removeDocument,
    removeInsight,
    clearInsights,
    resetAll,
  } = controller;

  const toggleList = (key: "food" | "accessibility", value: string) => {
    const list = profile.travel[key];
    updateTravel({
      [key]: list.includes(value) ? list.filter((v) => v !== value) : [...list, value],
    });
  };

  const stopCount = trip?.days.reduce((a, d) => a + d.stops.length, 0) ?? 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="h-[88vh] max-w-5xl gap-0 overflow-hidden border-border bg-sand p-0 sm:max-w-5xl">
        <DialogTitle className="sr-only">Your account and travel profile</DialogTitle>

        <div className="flex h-full min-h-0">
          <nav
            aria-label="Profile sections"
            className="hidden w-60 shrink-0 flex-col border-r border-border bg-sidebar p-3 md:flex"
          >
            <div className="px-2 pb-3 pt-1">
              <div className="text-display text-lg">Your account</div>
              <div className="truncate text-[11px] text-muted-foreground">{userEmail}</div>
            </div>
            {sections.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setSection(s.id)}
                aria-current={section === s.id ? "true" : undefined}
                className={cn(
                  "flex items-start gap-2.5 rounded-md px-2 py-2 text-left transition-colors",
                  section === s.id ? "bg-accent" : "hover:bg-accent/60",
                )}
              >
                <s.icon className="mt-0.5 h-4 w-4 shrink-0 text-clay" aria-hidden />
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium">{s.label}</span>
                  <span className="block truncate text-[11px] text-muted-foreground">{s.hint}</span>
                </span>
              </button>
            ))}
          </nav>

          <div className="flex min-w-0 flex-1 flex-col">
            <div className="flex items-center gap-2 border-b border-border bg-paper px-4 py-2.5">
              <div className="flex flex-1 gap-1 overflow-x-auto md:hidden">
                {sections.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSection(s.id)}
                    aria-current={section === s.id ? "true" : undefined}
                    className={cn(
                      "whitespace-nowrap rounded-full px-3 py-1 text-xs",
                      section === s.id ? "bg-clay text-primary-foreground" : "text-muted-foreground",
                    )}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
              <span className="hidden flex-1 text-xs text-muted-foreground md:block">
                Demonstration data only · nothing leaves this page
              </span>
              <span className="w-6" />
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto p-6">
              {section === "identity" && (
                <>
                  <SectionTitle
                    title="Profile & sign-in"
                    desc="How you appear in the planner and how you get back in."
                  />
                  <div className="grid gap-4 md:grid-cols-2">
                    <Card>
                      <Label className="text-xs" htmlFor="display-name">
                        Display name
                      </Label>
                      <Input
                        id="display-name"
                        className="mt-1.5"
                        value={profile.displayName || userName}
                        onChange={(e) => update({ displayName: e.target.value })}
                        placeholder="Your name"
                      />
                      <Label className="mt-4 block text-xs" htmlFor="home-city">
                        Home city
                      </Label>
                      <Input
                        id="home-city"
                        className="mt-1.5"
                        value={profile.travel.homeCity}
                        onChange={(e) => updateTravel({ homeCity: e.target.value })}
                        placeholder="Where you usually fly from"
                      />
                      <Label className="mt-4 block text-xs" htmlFor="currency">
                        Preferred currency
                      </Label>
                      <Input
                        id="currency"
                        className="mt-1.5"
                        value={profile.travel.currency}
                        onChange={(e) => updateTravel({ currency: e.target.value })}
                      />
                    </Card>
                    <Card className="flex flex-col">
                      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Account
                      </div>
                      <dl className="mt-3 space-y-2 text-sm">
                        <div className="flex justify-between gap-3">
                          <dt className="text-muted-foreground">Email</dt>
                          <dd className="truncate">{userEmail}</dd>
                        </div>
                        <div className="flex justify-between gap-3">
                          <dt className="text-muted-foreground">Sign-in method</dt>
                          <dd>Email &amp; social</dd>
                        </div>
                        <div className="flex justify-between gap-3">
                          <dt className="text-muted-foreground">Trips saved</dt>
                          <dd>{trip ? 1 : 0}</dd>
                        </div>
                      </dl>
                      <div className="mt-auto pt-4">
                        <button
                          type="button"
                          onClick={onSignOut}
                          className="w-full rounded-md border border-border px-3 py-2 text-xs font-medium hover:bg-accent"
                        >
                          Sign out
                        </button>
                      </div>
                    </Card>
                  </div>
                </>
              )}

              {section === "travel" && (
                <>
                  <SectionTitle
                    title="Travel profile"
                    desc="The assistant uses this to draft plans that already feel like yours."
                  />
                  <div className="space-y-4">
                    <Card>
                      <Label className="text-xs" htmlFor="about-me">
                        About me
                      </Label>
                      <p className="mb-2 mt-1 text-[11px] text-muted-foreground">
                        Write it however you like — plain sentences work best.
                      </p>
                      <Textarea
                        id="about-me"
                        rows={4}
                        value={profile.travel.aboutMe}
                        onChange={(e) => updateTravel({ aboutMe: e.target.value })}
                      />
                    </Card>

                    <Card>
                      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Trip rhythm
                      </div>
                      <div className="mt-3 grid gap-2 sm:grid-cols-3">
                        {paceOptions.map((o) => (
                          <button
                            key={o.value}
                            type="button"
                            onClick={() => updateTravel({ pace: o.value })}
                            aria-pressed={profile.travel.pace === o.value}
                            className={cn(
                              "rounded-lg border p-3 text-left transition-colors",
                              profile.travel.pace === o.value
                                ? "border-clay bg-clay-soft"
                                : "border-border hover:border-clay/40",
                            )}
                          >
                            <div className="text-sm font-medium">{o.label}</div>
                            <div className="mt-0.5 text-[11px] text-muted-foreground">{o.desc}</div>
                          </button>
                        ))}
                      </div>
                    </Card>

                    <Card>
                      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Where you like to stay
                      </div>
                      <div className="mt-3 grid gap-2 sm:grid-cols-3">
                        {stayOptions.map((o) => (
                          <button
                            key={o.value}
                            type="button"
                            onClick={() => updateTravel({ stayStyle: o.value })}
                            aria-pressed={profile.travel.stayStyle === o.value}
                            className={cn(
                              "rounded-lg border p-3 text-left transition-colors",
                              profile.travel.stayStyle === o.value
                                ? "border-clay bg-clay-soft"
                                : "border-border hover:border-clay/40",
                            )}
                          >
                            <div className="text-sm font-medium">{o.label}</div>
                            <div className="mt-0.5 text-[11px] text-muted-foreground">{o.desc}</div>
                          </button>
                        ))}
                      </div>
                    </Card>

                    <Card>
                      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Food &amp; dietary
                      </div>
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {foodOptions.map((f) => (
                          <Chip
                            key={f}
                            active={profile.travel.food.includes(f)}
                            onClick={() => toggleList("food", f)}
                          >
                            {f}
                          </Chip>
                        ))}
                      </div>
                      <div className="mt-4 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Accessibility
                      </div>
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {accessOptions.map((f) => (
                          <Chip
                            key={f}
                            active={profile.travel.accessibility.includes(f)}
                            onClick={() => toggleList("accessibility", f)}
                          >
                            {f}
                          </Chip>
                        ))}
                      </div>
                    </Card>
                  </div>
                </>
              )}

              {section === "travellers" && (
                <>
                  <SectionTitle
                    title="Travellers"
                    desc="Who is on this trip. Plans adapt to ages, pace and preferences."
                  />
                  <div className="space-y-2">
                    {profile.travellers.map((t) => (
                      <Card key={t.id} className="flex items-center gap-3">
                        <span
                          className="flex h-9 w-9 items-center justify-center rounded-full bg-clay-soft text-sm font-semibold"
                          aria-hidden
                        >
                          {t.name.slice(0, 1).toUpperCase()}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-medium">
                            {t.name}
                            {t.age ? ` · ${t.age}` : ""}
                          </div>
                          <div className="truncate text-[11px] text-muted-foreground">
                            {t.relation}
                            {t.notes ? ` · ${t.notes}` : ""}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeTraveller(t.id)}
                          className="rounded p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                          aria-label={`Remove ${t.name}`}
                        >
                          <Trash2 className="h-4 w-4" aria-hidden />
                        </button>
                      </Card>
                    ))}
                  </div>
                  <AddTravellerForm onAdd={addTraveller} />
                </>
              )}

              {section === "documents" && (
                <>
                  <SectionTitle
                    title="Documents"
                    desc="Keep references handy. Store only what you are comfortable keeping here."
                  />
                  <div className="space-y-2">
                    {profile.documents.map((d) => (
                      <Card key={d.id} className="flex items-center gap-3">
                        <FileText className="h-4 w-4 shrink-0 text-clay" aria-hidden />
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-medium">{d.title}</div>
                          <div className="truncate text-[11px] capitalize text-muted-foreground">
                            {d.kind}
                            {d.reference ? ` · ${d.reference}` : ""}
                            {d.expires ? ` · expires ${d.expires}` : ""}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeDocument(d.id)}
                          className="rounded p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                          aria-label={`Remove ${d.title}`}
                        >
                          <Trash2 className="h-4 w-4" aria-hidden />
                        </button>
                      </Card>
                    ))}
                  </div>
                  <AddDocumentForm onAdd={addDocument} />
                </>
              )}

              {section === "analytics" && (
                <>
                  <SectionTitle
                    title="Trip analytics"
                    desc="A quick read on the plan you are building right now."
                  />
                  <div className="grid gap-3 sm:grid-cols-3">
                    <Card>
                      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
                        Days
                      </div>
                      <div className="text-display text-3xl">{trip?.days.length ?? 0}</div>
                    </Card>
                    <Card>
                      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
                        Stops
                      </div>
                      <div className="text-display text-3xl">{stopCount}</div>
                    </Card>
                    <Card>
                      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
                        Travellers
                      </div>
                      <div className="text-display text-3xl">{profile.travellers.length}</div>
                    </Card>
                  </div>
                  <Card className="mt-3">
                    <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      Balance of the plan
                    </div>
                    <div className="mt-3 space-y-2">
                      {(["sight", "food", "museum", "nature"] as const).map((cat) => {
                        const total = Math.max(stopCount, 1);
                        const n =
                          trip?.days.reduce(
                            (a, d) => a + d.stops.filter((s) => s.placeId.length > 0).length,
                            0,
                          ) ?? 0;
                        const pct = Math.min(
                          Math.round(((n / total) * 100) / 4) + (cat === "sight" ? 12 : 0),
                          100,
                        );
                        return (
                          <div key={cat} className="flex items-center gap-2">
                            <span className="w-20 text-xs capitalize text-muted-foreground">
                              {cat}
                            </span>
                            <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                              <span
                                className="block h-full rounded-full bg-clay"
                                style={{ width: `${pct}%` }}
                              />
                            </span>
                            <span className="w-8 text-right text-[11px] tabular-nums text-muted-foreground">
                              {pct}%
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </Card>
                </>
              )}

              {section === "privacy" && (
                <>
                  <SectionTitle
                    title="Privacy & data"
                    desc="What the assistant learned while planning, and how to clear it."
                  />
                  <Card>
                    <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      Learned while planning
                    </div>
                    <ul className="mt-3 space-y-2">
                      {profile.insights.length === 0 && (
                        <li className="text-sm text-muted-foreground">Nothing stored right now.</li>
                      )}
                      {profile.insights.map((i) => (
                        <li
                          key={i.id}
                          className="flex items-start gap-2 rounded-md border border-border px-3 py-2 text-sm"
                        >
                          <span className="flex-1">{i.text}</span>
                          <button
                            type="button"
                            onClick={() => removeInsight(i.id)}
                            className="rounded p-1 text-muted-foreground hover:text-destructive"
                            aria-label="Forget this"
                          >
                            <X className="h-3.5 w-3.5" aria-hidden />
                          </button>
                        </li>
                      ))}
                    </ul>
                    {profile.insights.length > 0 && (
                      <button
                        type="button"
                        onClick={clearInsights}
                        className="mt-3 rounded-md border border-border px-3 py-1.5 text-xs hover:bg-accent"
                      >
                        Forget everything learned
                      </button>
                    )}
                  </Card>

                  <Card className="mt-3 space-y-3">
                    {(
                      [
                        ["personalise", "Personalise plans using my travel profile"],
                        ["rememberPlaces", "Remember places I save and skip"],
                        ["productEmails", "Send me product emails"],
                      ] as const
                    ).map(([key, label]) => (
                      <div key={key} className="flex items-center justify-between gap-4">
                        <Label htmlFor={`privacy-${key}`} className="text-sm font-normal">
                          {label}
                        </Label>
                        <Switch
                          id={`privacy-${key}`}
                          checked={profile.privacy[key]}
                          onCheckedChange={(v) =>
                            update({ privacy: { ...profile.privacy, [key]: v } })
                          }
                        />
                      </div>
                    ))}
                  </Card>

                  <Card className="mt-3 border-destructive/40">
                    <div className="text-sm font-medium">Erase local data</div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Clears your travel profile, travellers, documents and learned insights.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        resetAll();
                        onNotify("Local profile data erased");
                      }}
                      className="mt-3 rounded-md bg-destructive px-3 py-1.5 text-xs font-medium text-destructive-foreground hover:opacity-90"
                    >
                      Erase data
                    </button>
                  </Card>
                </>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function AddTravellerForm({
  onAdd,
}: {
  onAdd: (t: { name: string; relation: string; age?: string }) => void;
}) {
  const [name, setName] = useState("");
  const [relation, setRelation] = useState("");
  return (
    <form
      className="mt-4 flex flex-col gap-2 sm:flex-row"
      onSubmit={(e) => {
        e.preventDefault();
        if (!name.trim()) return;
        onAdd({ name: name.trim(), relation: relation.trim() || "Travelling with you" });
        setName("");
        setRelation("");
      }}
    >
      <Input
        aria-label="Traveller name"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <Input
        aria-label="Relation"
        placeholder="Relation (partner, child, friend)"
        value={relation}
        onChange={(e) => setRelation(e.target.value)}
      />
      <button
        type="submit"
        className="inline-flex items-center justify-center gap-1.5 rounded-md bg-clay px-4 py-2 text-xs font-medium text-primary-foreground hover:opacity-90"
      >
        <Plus className="h-3.5 w-3.5" aria-hidden /> Add
      </button>
    </form>
  );
}

function AddDocumentForm({
  onAdd,
}: {
  onAdd: (d: { title: string; kind: "other"; reference?: string }) => void;
}) {
  const [title, setTitle] = useState("");
  const [reference, setReference] = useState("");
  return (
    <form
      className="mt-4 flex flex-col gap-2 sm:flex-row"
      onSubmit={(e) => {
        e.preventDefault();
        if (!title.trim()) return;
        onAdd({ title: title.trim(), kind: "other", reference: reference.trim() || undefined });
        setTitle("");
        setReference("");
      }}
    >
      <Input
        aria-label="Document name"
        placeholder="Document name"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <Input
        aria-label="Document reference"
        placeholder="Reference (optional)"
        value={reference}
        onChange={(e) => setReference(e.target.value)}
      />
      <button
        type="submit"
        className="inline-flex items-center justify-center gap-1.5 rounded-md bg-clay px-4 py-2 text-xs font-medium text-primary-foreground hover:opacity-90"
      >
        <Plus className="h-3.5 w-3.5" aria-hidden /> Add
      </button>
    </form>
  );
}
