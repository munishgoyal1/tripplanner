export type PlaceCategory =
  | "sight"
  | "museum"
  | "food"
  | "nature"
  | "shopping"
  | "nightlife"
  | "stay"
  | "transit";

export interface Review {
  author: string;
  rating: number;
  date: string;
  text: string;
}

export interface Place {
  id: string;
  name: string;
  category: PlaceCategory;
  city: string;
  lat: number;
  lng: number;
  rating: number;
  reviewCount: number;
  ratingBreakdown: [number, number, number, number, number]; // 5★ → 1★
  priceLevel: 1 | 2 | 3 | 4;
  ticket?: string;
  typicalVisitMinutes: number;
  hours: { day: string; open: string }[];
  address: string;
  phone?: string;
  website?: string;
  tags: string[];
  blurb: string;
  photo: string;
  reviews: Review[];
}

export interface Stop {
  id: string;
  placeId: string;
  startTime: string;
  durationMinutes: number;
  travelToNextMinutes?: number;
  travelMode?: "walk" | "metro" | "car";
  note?: string;
}

export interface Day {
  id: string;
  date: string;
  title: string;
  stops: Stop[];
}

export interface Trip {
  id: string;
  name: string;
  destination: string;
  dateRange: string;
  travelers: number;
  cover: string;
  center: [number, number];
  days: Day[];
}


export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  chips?: string[];
}

export type TripPace = "relaxed" | "balanced" | "see_it_all";
export type StayStyle = "walkable" | "quiet" | "value";

export interface Traveller {
  id: string;
  name: string;
  relation: string;
  age?: string;
  notes?: string;
}

export interface TravelDocument {
  id: string;
  title: string;
  kind: "passport" | "visa" | "insurance" | "booking" | "other";
  reference?: string;
  expires?: string;
}

export interface LearnedInsight {
  id: string;
  text: string;
}

export interface TravelProfile {
  aboutMe: string;
  pace: TripPace;
  stayStyle: StayStyle;
  food: string[];
  accessibility: string[];
  homeCity: string;
  currency: string;
}

export interface ProfileState {
  displayName: string;
  travel: TravelProfile;
  travellers: Traveller[];
  documents: TravelDocument[];
  insights: LearnedInsight[];
  privacy: {
    personalise: boolean;
    rememberPlaces: boolean;
    productEmails: boolean;
  };
}

/** Which panel the workspace is focused on. */
export type WorkspaceView = "split" | "plan" | "map" | "guide";
