import type { Config } from "tailwindcss";

/** Colours are stored as raw oklch components so Tailwind opacity modifiers work. */
const token = (name: string) => `oklch(var(--${name}) / <alpha-value>)`;

export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        background: token("background"),
        foreground: token("foreground"),
        card: token("card"),
        "card-foreground": token("card-foreground"),
        popover: token("popover"),
        "popover-foreground": token("popover-foreground"),
        primary: token("primary"),
        "primary-foreground": token("primary-foreground"),
        secondary: token("secondary"),
        "secondary-foreground": token("secondary-foreground"),
        muted: token("muted"),
        "muted-foreground": token("muted-foreground"),
        accent: token("accent"),
        "accent-foreground": token("accent-foreground"),
        destructive: token("destructive"),
        "destructive-foreground": token("destructive-foreground"),
        border: token("border"),
        input: token("input"),
        ring: token("ring"),
        sand: token("sand"),
        paper: token("paper"),
        clay: token("clay"),
        "clay-soft": token("clay-soft"),
        sage: token("sage"),
        "sage-soft": token("sage-soft"),
        ochre: token("ochre"),
        ink: token("ink"),
        sidebar: token("sidebar"),
        "sidebar-foreground": token("sidebar-foreground"),
        "sidebar-border": token("sidebar-border"),
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        sans: ['"Work Sans"', "ui-sans-serif", "system-ui", "sans-serif"],
        display: ['"Instrument Serif"', "Georgia", "serif"],
      },
      boxShadow: {
        paper: "0 1px 2px oklch(0.28 0.05 45 / 0.06), 0 8px 24px -12px oklch(0.28 0.05 45 / 0.18)",
        lift: "0 2px 4px oklch(0.28 0.05 45 / 0.06), 0 18px 40px -18px oklch(0.28 0.05 45 / 0.28)",
      },
      keyframes: {
        "fade-in": { from: { opacity: "0" }, to: { opacity: "1" } },
        "scale-in": {
          from: { opacity: "0", transform: "scale(0.97)" },
          to: { opacity: "1", transform: "scale(1)" },
        },
      },
      animation: {
        "fade-in": "fade-in 150ms ease-out",
        "scale-in": "scale-in 150ms ease-out",
      },
    },
  },
  plugins: [],
} satisfies Config;
