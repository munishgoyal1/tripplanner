# AI Trip Planner — Workspace (presentation-only export)

Standalone **React 18 + TypeScript + Vite 6 + Tailwind CSS 3** build of the planner
workspace. No backend, no authentication, no database, no server components,
no generated APIs — every value on screen comes from one fixture file.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # type-check + production bundle
npm run typecheck
```

## Structure

```
src/
  App.tsx                     top-level state owner, wires props into the shell
  main.tsx                    React entry
  types.ts                    shared domain / profile / chat types
  fixtures/demoData.ts        ALL demonstration data (places, trips, chat, profile)
  state/usePlannerState.ts    planner interaction state + callbacks (local only)
  state/useProfileState.ts    traveller profile state + callbacks (in memory)
  components/
    shell/                    WorkspaceShell layout, GlobalBanner, TripWarnings strip
    toolbar/                  top bar: trips dropdown, view switcher, feedback, status, account menu
    itinerary/                itinerary panel + trip snapshot/readiness
    map/                      Leaflet map panel (dynamically imported)
    details/                  destination guide + place detail
    assistant/                docked assistant with canned replies + smart-defaults checkbox
    mobile/                   small-screen panel switcher
    profile/                  profile & settings overlay
    shared/                   PlaceThumb / CategoryIcon
    ui/                       accessible Radix primitives (dialog, menu, input…)
```

Components are presentational: they receive typed data and event callbacks
through props and hold only local UI state (open/expanded/search/drag).

## Notes

- Assistant replies are canned and simulated with a timeout.
- The map uses Leaflet with Carto Voyager tiles, loaded on demand in the browser.
- Icons come from `lucide-react`; fonts are loaded in `index.html`.
- New additions mirrored from the live planner: dismissible global banner, trips dropdown, thumbs-up/down + star rating feedback, and the “Let the agent decide with smart defaults” assistant checkbox.
