# AI Trip Planner — Landing Page + Planner Workspace (front-end)

A front-end-only build: a warm editorial travel landing page at `/` for guests, and the planner
workspace at `/planner`. All data is realistic mock data, structured so your existing backend can be
wired in later by swapping the data layer.

## Visual direction

Warm editorial travel: sand/paper background, terracotta and clay accents, deep ink text, sage as a
secondary. Serif display headlines paired with a clean sans for UI. Generous whitespace on the
landing page; tighter, information-dense but still warm surfaces inside the planner. All colors go in
as semantic tokens in `src/styles.css` so the app themes consistently (light first, dark-ready).

## 1. Landing page (`/`)

For signed-out guests. Sections:

- Slim top bar: wordmark left, minimal nav, "Sign in" top right.
- Hero: serif headline, one-line promise (quick, easy, reliable AI itineraries), a single primary
  action — an inline "Where to?" prompt field with dates/days chip that drops the guest straight into
  `/planner` with a prefilled draft.
- Live proof strip: a scaled-down, non-interactive miniature of the actual planner (itinerary rail +
  map + place card) so visitors see the product in the first screen.
- How it works: three steps (describe the trip → AI drafts day-by-day → refine with chat and swap
  places).
- Sample itineraries: editorial cards for a few destinations, each opening a read-only preview of a
  generated plan.
- Trust/quality band: what makes it reliable — real place data, opening hours, ticket info, travel
  times between stops.
- Footer: minimal, single row.

Each route gets its own `head()` metadata (title, description, og/twitter).

## 2. Planner workspace (`/planner`)

Keeps your four-panel model, refined:

```text
┌───────────────────────────────────────────────────────────────┐
│ logo   [ notification / status bar ]              [ account ] │
├──────────────┬───────────────────────────┬────────────────────┤
│ TRIPS +      │                           │  PLACE DETAIL      │
│ itinerary    │        MAP                │  photos, rating,   │
│ day by day   │   (pins, day routes)      │  reviews, hours,   │
│ drag to      │                           │  tickets, price    │
│ reorder      │                           │  [Add to Day 2]    │
├──────────────┴───────────────────────────┴────────────────────┤
│ ✦ Chat — collapsed to 2 rows, expandable                      │
└───────────────────────────────────────────────────────────────┘
```

Left rail (itinerary + trips)
- Trips switcher at the top: current trip name, dropdown listing saved trips with rename/delete and
  "New trip". Keeps the trip list out of the way instead of consuming a whole panel.
- Below it, the itinerary: day tabs/accordion, each stop as a compact card (time, name, category
  icon, duration, travel time to next stop). Drag to reorder, click to select, hover to highlight the
  matching map pin.
- Per-day footer: total walking/driving time and estimated spend.

Center (map)
- Numbered pins colored by day, polyline for the selected day, cluster on zoom out.
- Floating controls: day filter chips, "fit to day", category layer toggles.
- Selecting a pin selects the stop in the rail and loads the right panel — selection is shared state
  across all three panels.

Right (place detail)
- Hero photo strip, name, category, rating with review distribution, a few review excerpts.
- Metadata block: opening hours (today highlighted), ticket/price, typical visit duration, address,
  phone, website, tags.
- Actions: add to a day, replace this stop, save to shortlist, remove.
- When nothing is selected it becomes a discovery panel: suggested places near the selected day's
  cluster.

Bottom (chat)
- Docked 2-row composer with quick-action chips ("make day 3 lighter", "add food stops", "swap the
  museum"). Expands to a half-height panel with message history, collapses back.
- Assistant replies can carry inline result chips that highlight affected stops in the rail and map.

Top center (notification bar)
- Single-line status: autosave state, "itinerary updated", warnings such as a closed venue on the
  chosen day. Auto-dismisses, stacks quietly.

## 3. Interaction improvements I'd suggest

- One shared selection model (`selectedTripId`, `selectedDay`, `selectedPlaceId`) so rail, map and
  detail always agree — this is what makes the three-panel layout feel like one product.
- Panel resizing with draggable dividers, plus a focus mode that collapses the rail or detail panel.
- Responsive fallback: on tablet the right panel becomes an overlay sheet; on mobile the layout turns
  into map-first with the itinerary as a bottom sheet and chat as a floating button.
- Keyboard: `⌘K` command palette for jumping between trips, days and places; arrow keys to move
  between stops.
- Empty and loading states designed as first-class screens (new trip = a prompt-forward empty canvas,
  not a blank grid).

## 4. Guest vs signed-in routing

- `/` renders the landing page for guests.
- A mock auth context (`useSession`) drives the header: signed-out shows "Sign in", signed-in shows
  the account menu.
- If a session exists and the user has at least one trip, `/` redirects to `/planner`. Signed in with
  no trips lands on the planner's new-trip empty state.
- Sign-in is a UI-only modal for now; when you wire your backend, only the session provider changes.

## Technical notes

- Routes: `src/routes/index.tsx` (landing), `src/routes/planner.tsx` (workspace), each with its own
  `head()` metadata.
- Design tokens (warm palette, serif/sans pairing, radii, shadows) defined in `src/styles.css`;
  fonts loaded via `<link>` in `__root.tsx`. No hardcoded color classes in components.
- Mock data in `src/data/` — trips, days, places with full metadata and reviews — behind small
  typed accessors so swapping in your API later is a one-file change.
- Map: interactive map library loaded client-only (dynamic import behind `ClientOnly`) so SSR stays
  clean.
- Planner state in a single React context/store; no backend calls, no persistence beyond
  in-memory state this pass.
- Chat panel is UI-only with scripted mock responses — no AI calls until you decide to connect them.

## Out of scope this pass

Real auth, database, AI generation, and live place data — those stay with your existing backend.
