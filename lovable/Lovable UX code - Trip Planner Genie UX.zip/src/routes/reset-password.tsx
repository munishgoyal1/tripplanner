import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Compass, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Set a new password — AI Trip Planner" },
      { name: "description", content: "Choose a new password for your AI Trip Planner account." },
      { property: "og:title", content: "Set a new password — AI Trip Planner" },
      { property: "og:description", content: "Choose a new password for your account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const hash = window.location.hash;
    void supabase.auth.getSession().then(({ data }) => {
      setReady(Boolean(data.session) || hash.includes("type=recovery"));
    });
  }, []);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { error: err } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (err) {
      setError(err.message);
      return;
    }
    setDone(true);
    setTimeout(() => navigate({ to: "/planner", replace: true }), 900);
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <span className="inline-flex items-center gap-2">
          <Compass className="h-4 w-4 text-clay" />
          <span className="text-display text-lg">AI Trip Planner</span>
        </span>
        <h1 className="mt-5 text-display text-3xl">Set a new password</h1>

        {!ready ? (
          <p className="mt-3 text-sm text-muted-foreground">
            This reset link looks expired or already used.{" "}
            <Link to="/auth" className="text-clay underline-offset-4 hover:underline">
              Request a new one
            </Link>
            .
          </p>
        ) : done ? (
          <p className="mt-3 text-sm text-muted-foreground">Password updated. Taking you in…</p>
        ) : (
          <form onSubmit={handleSubmit} className="mt-6 grid gap-3">
            <label className="block">
              <span className="mb-1.5 block text-xs font-medium text-muted-foreground">
                New password
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                minLength={8}
                required
                autoComplete="new-password"
                className="h-11 w-full rounded-lg border border-border bg-paper px-3 text-sm outline-none focus:border-clay focus:ring-2 focus:ring-clay/20"
              />
            </label>
            {error && (
              <p role="alert" className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                {error}
              </p>
            )}
            <button
              type="submit"
              disabled={busy}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-clay text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-60"
            >
              {busy && <Loader2 className="h-4 w-4 animate-spin" />}
              Update password
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
