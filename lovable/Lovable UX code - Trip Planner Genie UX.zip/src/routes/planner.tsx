import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ClientOnly } from "@tanstack/react-router";
import { PlannerProvider } from "@/lib/planner-store";
import { ProfileProvider } from "@/lib/profile-store";
import { PlannerTopBar, type PlannerView } from "@/components/planner/PlannerTopBar";
import { ItineraryRail } from "@/components/planner/ItineraryRail";
import { PlaceDetail } from "@/components/planner/PlaceDetail";
import { ChatDock } from "@/components/planner/ChatDock";
import { MapPanel } from "@/components/planner/MapPanel";
import { TripWarnings } from "@/components/planner/TripWarnings";
import { ProfileOverlay } from "@/components/planner/ProfileOverlay";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/planner")({
  head: () => ({
    meta: [
      { title: "Planner workspace — AI Trip Planner" },
      {
        name: "description",
        content:
          "Build and refine your itinerary: day-by-day plan, live map, place details with hours and tickets, and an AI assistant docked below.",
      },
      { property: "og:title", content: "Planner workspace — AI Trip Planner" },
      {
        property: "og:description",
        content: "Itinerary, map, place details and an AI assistant in one workspace.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/planner" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
    links: [{ rel: "canonical", href: "/planner" }],
  }),
  component: PlannerPage,
});

function PlannerPage() {
  const [view, setView] = useState<PlannerView>("split");
  const [profileOpen, setProfileOpen] = useState(false);

  const showRail = view === "split" || view === "plan";
  const showMap = view === "split" || view === "map";
  const showGuide = view === "split" || view === "guide";

  return (
    <ProfileProvider>
      <PlannerProvider>
        <div className="flex h-screen flex-col overflow-hidden bg-sand">
          <PlannerTopBar
            view={view}
            onViewChange={setView}
            onOpenProfile={() => setProfileOpen(true)}
          />
          <TripWarnings />

          <div className="flex min-h-0 flex-1">
            {showRail && (
              <aside
                className={cn(
                  "shrink-0 border-r border-border",
                  view === "plan"
                    ? "w-full"
                    : "hidden w-[300px] md:block xl:w-[340px]",
                )}
              >
                <ItineraryRail />
              </aside>
            )}

            {showMap && (
              <div className="relative z-0 min-w-0 flex-1">
                <ClientOnly fallback={<div className="h-full w-full bg-sand" />}>
                  <MapPanel />
                </ClientOnly>
              </div>
            )}

            {showGuide && (
              <aside
                className={cn(
                  "shrink-0 border-l border-border",
                  view === "guide" ? "w-full" : "hidden w-[360px] lg:block xl:w-[400px]",
                )}
              >
                <PlaceDetail />
              </aside>
            )}
          </div>

          <ChatDock />

          <ProfileOverlay open={profileOpen} onOpenChange={setProfileOpen} />
        </div>
      </PlannerProvider>
    </ProfileProvider>
  );
}
