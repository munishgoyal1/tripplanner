import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  Clock3,
  Compass,
  MapPinned,
  MessagesSquare,
  Search,
  ShieldCheck,
  Ticket,
} from "lucide-react";
import heroImage from "@/assets/hero-travel.jpg";
import { PlannerPreview } from "@/components/landing/PlannerPreview";
import { AgentReplay } from "@/components/landing/AgentReplay";
import { sampleItineraries } from "@/data/trips";
import { useSession } from "@/lib/session";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AI Trip Planner — itineraries you can actually follow" },
      {
        name: "description",
        content:
          "Describe your trip and get a day-by-day itinerary in seconds: real opening hours, tickets and travel times, refined by chat on a live map.",
      },
      { property: "og:title", content: "AI Trip Planner — itineraries you can actually follow" },
      {
        property: "og:description",
        content:
          "Quick, easy and reliable AI itinerary planning with a live map, place details and a chat assistant.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebApplication",
          name: "AI Trip Planner",
          applicationCategory: "TravelApplication",
          description:
            "AI itinerary planner with a live map, place details and a chat assistant.",
        }),
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  const { user } = useSession();
  const navigate = useNavigate();
  const [prompt, setPrompt] = useState("");

  // Signed-in travellers with a trip go straight to the workspace.
  useEffect(() => {
    if (user) navigate({ to: "/planner" });
  }, [user, navigate]);

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-6 px-5">
          <span className="inline-flex items-center gap-2">
            <Compass className="h-4 w-4 text-clay" />
            <span className="text-display text-lg">AI Trip Planner</span>
          </span>
          <nav className="hidden gap-6 text-sm text-muted-foreground sm:flex">
            <a href="#how" className="hover:text-foreground">
              How it works
            </a>
            <a href="#samples" className="hover:text-foreground">
              Sample trips
            </a>
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <Link
              to="/auth"
              className="rounded-full px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground"
            >
              Sign in
            </Link>
            <Link
              to="/auth"
              className="rounded-full bg-clay px-3.5 py-1.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
            >
              Create account
            </Link>
          </div>
        </div>
      </header>

      <main>
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 lg:grid-cols-[1.05fr_1fr] lg:py-24">
            <div>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-sand px-3 py-1 text-[11px] uppercase tracking-wide text-muted-foreground">
                <ShieldCheck className="h-3 w-3 text-sage" /> Hours, tickets and travel times
                checked
              </span>
              <h1 className="mt-5 text-display text-5xl leading-[1.05] sm:text-6xl">
                A trip worth taking,
                <br />
                planned before your coffee cools.
              </h1>
              <p className="mt-5 max-w-lg text-base leading-relaxed text-muted-foreground">
                Tell us where you are going. You get a day-by-day itinerary that respects opening
                hours, ticket rules and how long it really takes to cross town — then refine it by
                chatting.
              </p>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  navigate({ to: "/planner" });
                }}
                className="mt-8 flex max-w-lg flex-col gap-2 rounded-xl border border-border bg-paper p-2 shadow-paper sm:flex-row sm:items-center"
              >
                <span className="flex flex-1 items-center gap-2 px-2">
                  <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
                  <input
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Kyoto for 5 days in April, temples and food"
                    className="w-full bg-transparent py-2 text-sm outline-none placeholder:text-muted-foreground"
                    aria-label="Describe your trip"
                  />
                </span>
                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-clay px-4 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
                >
                  Plan it <ArrowRight className="h-4 w-4" />
                </button>
              </form>
              <p className="mt-2 text-xs text-muted-foreground">
                No account needed to see your first itinerary.
              </p>
            </div>

            <div className="relative">
              <img
                src={heroImage}
                alt="Sunlit hillside town with terracotta rooftops and a winding stone lane"
                width={1600}
                height={1104}
                className="aspect-4/3 w-full rounded-xl object-cover shadow-lift"
              />
              <div className="absolute -bottom-6 -left-4 hidden w-64 rounded-lg border border-border bg-paper p-3 shadow-lift sm:block">
                <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
                  Draft ready
                </p>
                <p className="mt-1 text-display text-lg leading-tight">
                  5 days · 19 stops · 0 clashes
                </p>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Generated in 11 seconds from one sentence.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Live proof */}
        <section className="border-y border-border bg-sand/60 py-16">
          <div className="mx-auto max-w-6xl px-5">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <h2 className="max-w-md text-display text-3xl leading-tight">
                This is the workspace you land in.
              </h2>
              <p className="max-w-sm text-sm text-muted-foreground">
                Itinerary on the left, live map in the middle, everything you need to know about a
                place on the right, and the assistant docked below.
              </p>
            </div>
            <PlannerPreview />
          </div>
        </section>

        {/* How it works */}
        <section id="how" className="py-20">
          <div className="mx-auto max-w-6xl px-5">
            <h2 className="text-display text-3xl">Three steps, one sentence of effort</h2>
            <ol className="mt-10 grid gap-8 sm:grid-cols-3">
              {[
                {
                  icon: MessagesSquare,
                  title: "Describe the trip",
                  body: "City, dates, pace, what you care about. One sentence is enough — the assistant asks only if something is genuinely missing.",
                },
                {
                  icon: MapPinned,
                  title: "Get a day-by-day draft",
                  body: "Stops clustered by neighbourhood, ordered around opening hours, with honest travel times between them.",
                },
                {
                  icon: Clock3,
                  title: "Refine as you go",
                  body: "Drag to reorder, swap a stop, or ask for a lighter day. The map and timings update with you.",
                },
              ].map((step, i) => (
                <li key={step.title}>
                  <span className="inline-flex items-center gap-2 text-xs text-muted-foreground">
                    <step.icon className="h-4 w-4 text-clay" /> Step {i + 1}
                  </span>
                  <h3 className="mt-3 text-xl">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* Agent replay */}
        <section id="replay" className="border-t border-border bg-paper py-20">
          <div className="mx-auto grid max-w-6xl gap-10 px-5 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
            <div>
              <span className="text-xs uppercase tracking-wide text-muted-foreground">
                Watch it work
              </span>
              <h2 className="mt-3 text-display text-3xl leading-tight">
                See exactly how the plan gets made
              </h2>
              <p className="mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                No black box. Every change the assistant makes is shown as a step you can read — what
                it removed, what it added, and why. Press play to replay a real four-day Kyoto
                session.
              </p>
            </div>
            <AgentReplay />
          </div>
        </section>

        {/* Sample itineraries */}
        <section id="samples" className="border-t border-border bg-sand/60 py-20">
          <div className="mx-auto max-w-6xl px-5">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <h2 className="text-display text-3xl">Start from a plan that already works</h2>
              <Link to="/planner" className="text-sm text-clay underline-offset-4 hover:underline">
                Open the planner
              </Link>
            </div>

            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {sampleItineraries.map((s) => (
                <Link
                  key={s.id}
                  to="/planner"
                  className="group flex flex-col overflow-hidden rounded-xl border border-border bg-paper shadow-paper transition-shadow hover:shadow-lift"
                >
                  <span
                    className={`grain block h-32 bg-linear-to-br ${
                      s.swatch === "clay"
                        ? "from-clay-soft to-clay/60"
                        : s.swatch === "sage"
                          ? "from-sage-soft to-sage/60"
                          : "from-accent to-ochre/60"
                    }`}
                  />
                  <span className="flex flex-1 flex-col p-4">
                    <span className="flex items-baseline justify-between">
                      <span className="text-display text-xl">{s.destination}</span>
                      <span className="text-xs text-muted-foreground">{s.length}</span>
                    </span>
                    <span className="mt-1 text-sm text-muted-foreground">{s.tone}</span>
                    <ul className="mt-3 space-y-1 text-xs text-muted-foreground">
                      {s.highlights.map((h) => (
                        <li key={h} className="flex items-center gap-1.5">
                          <span className="h-1 w-1 rounded-full bg-clay" />
                          {h}
                        </li>
                      ))}
                    </ul>
                    <span className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-clay">
                      Preview the plan
                      <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                    </span>
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Reliability */}
        <section className="py-20">
          <div className="mx-auto grid max-w-6xl gap-10 px-5 lg:grid-cols-[0.9fr_1.1fr]">
            <h2 className="text-display text-3xl leading-tight">
              Reliable is the hard part.
              <br />
              That is the part we built.
            </h2>
            <dl className="grid gap-6 sm:grid-cols-2">
              {[
                {
                  icon: Clock3,
                  t: "Opening hours respected",
                  d: "Nothing is scheduled for a day a place is closed, and evening stops sit inside real last-entry times.",
                },
                {
                  icon: Ticket,
                  t: "Tickets and prices upfront",
                  d: "Entry costs, reservation rules and typical visit lengths sit next to every stop.",
                },
                {
                  icon: MapPinned,
                  t: "Honest travel times",
                  d: "Walking, metro and driving times between consecutive stops, not optimistic straight lines.",
                },
                {
                  icon: ShieldCheck,
                  t: "Real place data",
                  d: "Ratings, review counts and metadata from the sources travellers already trust.",
                },
              ].map((f) => (
                <div key={f.t}>
                  <dt className="flex items-center gap-2 text-sm font-medium">
                    <f.icon className="h-4 w-4 text-clay" /> {f.t}
                  </dt>
                  <dd className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{f.d}</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>

        <section className="border-t border-border bg-ink py-16 text-background">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-6 px-5">
            <h2 className="max-w-md text-display text-3xl leading-tight">
              Your next trip is one sentence away.
            </h2>
            <Link
              to="/planner"
              className="inline-flex items-center gap-2 rounded-full bg-clay px-5 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
            >
              Open the planner <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </section>
      </main>

      <footer className="border-t border-border py-6">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <Compass className="h-3.5 w-3.5 text-clay" /> aitripplanner.co
          </span>
          <span>© {new Date().getFullYear()} AI Trip Planner · Plan quickly, travel slowly.</span>
        </div>
      </footer>
    </div>
  );
}
