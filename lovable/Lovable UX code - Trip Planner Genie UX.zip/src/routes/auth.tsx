import { createFileRoute, Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { ArrowLeft, Compass, Loader2, Mail, MapPinned, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useSession } from "@/lib/session";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — AI Trip Planner" },
      {
        name: "description",
        content:
          "Create an account or sign in to save your itineraries and pick up planning exactly where you left off.",
      },
      { property: "og:title", content: "Sign in — AI Trip Planner" },
      {
        property: "og:description",
        content: "Save your itineraries and return to them from any device.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/auth" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/auth" }],
  }),
  component: AuthPage,
});

type Mode = "signin" | "signup" | "magic" | "forgot";

const copy: Record<Mode, { title: string; sub: string; cta: string }> = {
  signin: {
    title: "Welcome back",
    sub: "Sign in to pick up your itineraries where you left them.",
    cta: "Sign in",
  },
  signup: {
    title: "Create your account",
    sub: "Save every trip you plan and return to it from any device.",
    cta: "Create account",
  },
  magic: {
    title: "Sign in with a link",
    sub: "We'll email you a one-tap link — no password to remember.",
    cta: "Email me a link",
  },
  forgot: {
    title: "Reset your password",
    sub: "Enter your email and we'll send a link to set a new password.",
    cta: "Send reset link",
  },
};

function AuthPage() {
  const { user } = useSession();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  const [mode, setMode] = useState<Mode>("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState<null | "email" | "google" | "apple">(null);
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState<string | null>(null);

  useEffect(() => {
    if (user && pathname === "/auth") navigate({ to: "/planner", replace: true });
  }, [user, pathname, navigate]);

  function reset(next: Mode) {
    setMode(next);
    setError(null);
    setSent(null);
  }

  async function handleOAuth(provider: "google" | "apple") {
    setError(null);
    setBusy(provider);
    try {
      const result = await lovable.auth.signInWithOAuth(provider, {
        redirect_uri: window.location.origin,
      });
      if (result.error) {
        setError(result.error.message ?? "That sign-in didn't go through. Please try again.");
        setBusy(null);
        return;
      }
      if (result.redirected) return;
      navigate({ to: "/planner", replace: true });
    } catch {
      setError("That sign-in didn't go through. Please try again.");
    } finally {
      setBusy(null);
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSent(null);
    setBusy("email");
    try {
      if (mode === "signin") {
        const { error: err } = await supabase.auth.signInWithPassword({ email, password });
        if (err) throw err;
        navigate({ to: "/planner", replace: true });
      } else if (mode === "signup") {
        const { data, error: err } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { display_name: name || email.split("@")[0] },
          },
        });
        if (err) throw err;
        if (data.session) navigate({ to: "/planner", replace: true });
        else setSent("Check your inbox to confirm your email, then sign in.");
      } else if (mode === "magic") {
        const { error: err } = await supabase.auth.signInWithOtp({
          email,
          options: { emailRedirectTo: window.location.origin },
        });
        if (err) throw err;
        setSent("Link sent. Open it on this device to finish signing in.");
      } else {
        const { error: err } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (err) throw err;
        setSent("Reset link sent. Check your inbox.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setBusy(null);
    }
  }

  const c = copy[mode];

  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1.05fr]">
      {/* Form side */}
      <div className="flex flex-col px-6 py-8 sm:px-12">
        <Link
          to="/"
          className="inline-flex items-center gap-2 self-start text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Back to home
        </Link>

        <div className="mx-auto flex w-full max-w-sm flex-1 flex-col justify-center py-10">
          <span className="inline-flex items-center gap-2">
            <Compass className="h-4 w-4 text-clay" />
            <span className="text-display text-lg">AI Trip Planner</span>
          </span>

          <h1 className="mt-6 text-display text-4xl leading-tight">{c.title}</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{c.sub}</p>

          {mode !== "forgot" && (
            <>
              <div className="mt-7 grid gap-2">
                <button
                  type="button"
                  onClick={() => handleOAuth("google")}
                  disabled={busy !== null}
                  className="inline-flex h-11 items-center justify-center gap-2.5 rounded-lg border border-border bg-paper text-sm font-medium transition-colors hover:bg-accent disabled:opacity-60"
                >
                  {busy === "google" ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <GoogleMark />
                  )}
                  Continue with Google
                </button>
                <button
                  type="button"
                  onClick={() => handleOAuth("apple")}
                  disabled={busy !== null}
                  className="inline-flex h-11 items-center justify-center gap-2.5 rounded-lg border border-border bg-ink text-sm font-medium text-background transition-opacity hover:opacity-90 disabled:opacity-60"
                >
                  {busy === "apple" ? <Loader2 className="h-4 w-4 animate-spin" /> : <AppleMark />}
                  Continue with Apple
                </button>
              </div>

              <div className="my-6 flex items-center gap-3">
                <span className="h-px flex-1 bg-border" />
                <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
                  or with email
                </span>
                <span className="h-px flex-1 bg-border" />
              </div>
            </>
          )}

          <form onSubmit={handleSubmit} className={mode === "forgot" ? "mt-7 grid gap-3" : "grid gap-3"}>
            {mode === "signup" && (
              <Field
                label="Name"
                type="text"
                value={name}
                onChange={setName}
                placeholder="Munish"
                autoComplete="name"
              />
            )}
            <Field
              label="Email"
              type="email"
              value={email}
              onChange={setEmail}
              placeholder="you@example.com"
              autoComplete="email"
              required
            />
            {(mode === "signin" || mode === "signup") && (
              <div>
                <Field
                  label="Password"
                  type="password"
                  value={password}
                  onChange={setPassword}
                  placeholder="At least 8 characters"
                  autoComplete={mode === "signin" ? "current-password" : "new-password"}
                  minLength={8}
                  required
                />
                {mode === "signin" && (
                  <button
                    type="button"
                    onClick={() => reset("forgot")}
                    className="mt-1.5 text-xs text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
                  >
                    Forgot your password?
                  </button>
                )}
              </div>
            )}

            {error && (
              <p
                role="alert"
                className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive"
              >
                {error}
              </p>
            )}
            {sent && (
              <p className="inline-flex items-start gap-2 rounded-md border border-sage/40 bg-sage-soft/40 px-3 py-2 text-xs text-foreground">
                <Mail className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sage" />
                {sent}
              </p>
            )}

            <button
              type="submit"
              disabled={busy !== null}
              className="mt-1 inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-clay text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
            >
              {busy === "email" && <Loader2 className="h-4 w-4 animate-spin" />}
              {c.cta}
            </button>
          </form>

          <div className="mt-6 space-y-1.5 text-xs text-muted-foreground">
            {mode === "signin" && (
              <>
                <p>
                  New here?{" "}
                  <button
                    onClick={() => reset("signup")}
                    className="text-clay underline-offset-4 hover:underline"
                  >
                    Create an account
                  </button>
                </p>
                <p>
                  Prefer no password?{" "}
                  <button
                    onClick={() => reset("magic")}
                    className="text-clay underline-offset-4 hover:underline"
                  >
                    Email me a sign-in link
                  </button>
                </p>
              </>
            )}
            {mode === "signup" && (
              <p>
                Already have an account?{" "}
                <button
                  onClick={() => reset("signin")}
                  className="text-clay underline-offset-4 hover:underline"
                >
                  Sign in
                </button>
              </p>
            )}
            {(mode === "magic" || mode === "forgot") && (
              <p>
                <button
                  onClick={() => reset("signin")}
                  className="text-clay underline-offset-4 hover:underline"
                >
                  Back to sign in
                </button>
              </p>
            )}
            <p className="pt-2 text-[11px] leading-relaxed">
              By continuing you agree that we store your itineraries so you can return to them.
            </p>
          </div>
        </div>
      </div>

      {/* Editorial side */}
      <aside className="relative hidden overflow-hidden border-l border-border bg-ink text-background lg:block">
        <div className="grain absolute inset-0 opacity-30" aria-hidden />
        <div className="relative flex h-full flex-col justify-between p-12">
          <span className="text-[11px] uppercase tracking-[0.2em] text-background/60">
            aitripplanner.co
          </span>

          <div>
            <h2 className="text-display text-4xl leading-tight">
              Every trip you plan,
              <br />
              waiting where you left it.
            </h2>
            <ul className="mt-8 space-y-5">
              {[
                {
                  icon: MapPinned,
                  t: "Your itineraries, saved",
                  d: "Days, stops and timings persist across devices — no more losing a plan to a closed tab.",
                },
                {
                  icon: Sparkles,
                  t: "The assistant remembers",
                  d: "Come back tomorrow and keep refining the same trip in the same conversation.",
                },
                {
                  icon: Compass,
                  t: "Straight into the workspace",
                  d: "Once you have a trip, signing in drops you right back into the planner.",
                },
              ].map((f) => (
                <li key={f.t} className="flex gap-3">
                  <f.icon className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                  <span>
                    <span className="block text-sm font-medium">{f.t}</span>
                    <span className="mt-0.5 block text-sm leading-relaxed text-background/70">
                      {f.d}
                    </span>
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <figure className="max-w-sm border-l-2 border-accent pl-4">
            <blockquote className="text-display text-lg leading-snug">
              “I described five days in Kyoto in one sentence and spent the evening editing, not
              researching.”
            </blockquote>
            <figcaption className="mt-2 text-xs text-background/60">
              Priya R. — planned 3 trips this year
            </figcaption>
          </figure>
        </div>
      </aside>
    </div>
  );
}

function Field({
  label,
  type,
  value,
  onChange,
  placeholder,
  autoComplete,
  required,
  minLength,
}: {
  label: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  autoComplete?: string;
  required?: boolean;
  minLength?: number;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete={autoComplete}
        required={required}
        minLength={minLength}
        className="h-11 w-full rounded-lg border border-border bg-paper px-3 text-sm outline-none transition-shadow placeholder:text-muted-foreground focus:border-clay focus:ring-2 focus:ring-clay/20"
      />
    </label>
  );
}

function GoogleMark() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden>
      <path
        fill="#4285F4"
        d="M23.5 12.27c0-.79-.07-1.54-.2-2.27H12v4.51h6.47a5.53 5.53 0 0 1-2.4 3.63v3h3.88c2.27-2.09 3.55-5.17 3.55-8.87Z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.96-1.08 7.95-2.91l-3.88-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.28v3.09A12 12 0 0 0 12 24Z"
      />
      <path
        fill="#FBBC05"
        d="M5.27 14.29a7.2 7.2 0 0 1 0-4.58V6.62H1.28a12 12 0 0 0 0 10.76l3.99-3.09Z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.44-3.44C17.95 1.19 15.24 0 12 0A12 12 0 0 0 1.28 6.62l3.99 3.09C6.22 6.86 8.87 4.75 12 4.75Z"
      />
    </svg>
  );
}

function AppleMark() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M16.36 12.78c.02 2.6 2.28 3.47 2.3 3.48-.02.06-.36 1.24-1.19 2.45-.72 1.05-1.47 2.1-2.65 2.12-1.16.02-1.53-.69-2.85-.69-1.32 0-1.74.67-2.83.71-1.14.04-2.01-1.13-2.73-2.18-1.49-2.15-2.63-6.09-1.1-8.75a4.24 4.24 0 0 1 3.58-2.17c1.12-.02 2.17.75 2.85.75.68 0 1.96-.93 3.3-.79.56.02 2.14.23 3.15 1.71-.08.05-1.88 1.1-1.86 3.28M14.2 4.4c.6-.73 1-1.74.89-2.75-.86.04-1.9.58-2.52 1.3-.55.65-1.04 1.68-.91 2.67.96.07 1.94-.49 2.54-1.22" />
    </svg>
  );
}
