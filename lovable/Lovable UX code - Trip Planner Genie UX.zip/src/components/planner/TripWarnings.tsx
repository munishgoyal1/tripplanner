import { AlertTriangle, ArrowRight, X } from "lucide-react";
import { useMemo, useState } from "react";
import { placesById } from "@/data/trips";
import { usePlanner } from "@/lib/planner-store";

interface Gap {
  id: string;
  text: string;
  action: string;
}

export function TripWarnings() {
  const { trip, sendMessage, notify } = usePlanner();
  const [dismissed, setDismissed] = useState<string[]>([]);

  const gaps = useMemo<Gap[]>(() => {
    if (!trip) return [];
    const list: Gap[] = [];

    if (trip.dateRange === "Dates to set") {
      list.push({ id: "dates", text: "This trip has no dates yet.", action: "Set dates" });
    }

    const emptyDay = trip.days.find((d) => d.stops.length === 0);
    if (emptyDay) {
      list.push({ id: `empty-${emptyDay.id}`, text: `${emptyDay.title} has nothing planned.`, action: "Fill this day" });
    }

    const noFoodDay = trip.days.find(
      (d) => d.stops.length > 2 && !d.stops.some((s) => placesById[s.placeId]?.category === "food"),
    );
    if (noFoodDay) {
      list.push({
        id: `food-${noFoodDay.id}`,
        text: `No meal stop on ${noFoodDay.title}.`,
        action: "Add food stops",
      });
    }

    const heavyDay = trip.days.find((d) => d.stops.length >= 5);
    if (heavyDay) {
      list.push({
        id: `heavy-${heavyDay.id}`,
        text: `${heavyDay.title} looks packed — ${heavyDay.stops.length} stops.`,
        action: "Make it lighter",
      });
    }

    const noStay = !trip.days.some((d) => d.stops.some((s) => placesById[s.placeId]?.category === "stay"));
    if (noStay) {
      list.push({ id: "stay", text: "No accommodation saved for this trip.", action: "Suggest stays" });
    }

    return list;
  }, [trip]);

  const visible = gaps.filter((g) => !dismissed.includes(g.id));
  if (visible.length === 0) return null;

  const gap = visible[0]!;

  return (
    <div className="flex shrink-0 items-center gap-3 border-b border-ochre/40 bg-ochre/15 px-3 py-1.5 text-xs">
      <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-ochre" />
      <span className="min-w-0 flex-1 truncate">{gap.text}</span>
      {visible.length > 1 && (
        <span className="hidden rounded-full bg-paper px-2 py-0.5 text-[10px] text-muted-foreground sm:inline">
          +{visible.length - 1} more
        </span>
      )}
      <button
        onClick={() => {
          sendMessage(gap.action);
          notify("Assistant is working on it");
          setDismissed((d) => [...d, gap.id]);
        }}
        className="inline-flex items-center gap-1 rounded-full bg-clay px-2.5 py-1 font-medium text-primary-foreground hover:opacity-90"
      >
        {gap.action} <ArrowRight className="h-3 w-3" />
      </button>
      <button
        onClick={() => setDismissed((d) => [...d, gap.id])}
        className="rounded p-1 text-muted-foreground hover:text-foreground"
        aria-label="Dismiss warning"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
