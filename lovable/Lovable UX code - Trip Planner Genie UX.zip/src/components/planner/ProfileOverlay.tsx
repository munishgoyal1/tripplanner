import { useState } from "react";
import {
  BarChart3,
  FileText,
  Fingerprint,
  Plus,
  Shield,
  Sparkles,
  Trash2,
  Users,
  X,
} from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useProfile, type StayStyle, type TripPace } from "@/lib/profile-store";
import { useSession } from "@/lib/session";
import { usePlanner } from "@/lib/planner-store";
import { cn } from "@/lib/utils";

type SectionId = "identity" | "travel" | "travellers" | "documents" | "analytics" | "privacy";

const sections: { id: SectionId; label: string; icon: typeof Fingerprint; hint: string }[] = [
  { id: "identity", label: "Profile & sign-in", icon: Fingerprint, hint: "Name, email, account" },
  { id: "travel", label: "Travel profile", icon: Sparkles, hint: "How you like to travel" },
  { id: "travellers", label: "Travellers", icon: Users, hint: "Who is coming along" },
  { id: "documents", label: "Documents", icon: FileText, hint: "Passports, visas, bookings" },
  { id: "analytics", label: "Trip analytics", icon: BarChart3, hint: "Your planning patterns" },
  { id: "privacy", label: "Privacy & data", icon: Shield, hint: "What we remember" },
];

const paceOptions: { value: TripPace; label: string; desc: string }[] = [
  { value: "relaxed", label: "Relaxed", desc: "Two or three things a day, long meals" },
  { value: "balanced", label: "Balanced", desc: "A full but unhurried day" },
  { value: "see_it_all", label: "See it all", desc: "Early starts, packed days" },
];

const stayOptions: { value: StayStyle; label: string; desc: string }[] = [
  { value: "walkable", label: "Walkable centre", desc: "Pay more, walk everywhere" },
  { value: "quiet", label: "Quiet street", desc: "Calm nights over buzz" },
  { value: "value", label: "Best value", desc: "Happy to commute a little" },
];

const foodOptions = [
  "Vegetarian friendly",
  "Vegan options",
  "Halal",
  "No shellfish",
  "No pork",
  "Gluten free",
  "Loves street food",
  "Fine dining night",
];

const accessOptions = ["Stroller friendly", "Step-free access", "Short walks only", "Quiet spaces"];

function SectionTitle({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="mb-5">
      <h2 className="text-display text-2xl">{title}</h2>
      <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
    </div>
  );
}

function Chip({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-full border px-3 py-1.5 text-xs transition-colors",
        active
          ? "border-clay bg-clay-soft text-foreground"
          : "border-border bg-paper text-muted-foreground hover:border-clay/40 hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}

function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={cn("panel p-4", className)}>{children}</div>;
}

export function ProfileOverlay({
  open,
  onOpenChange,
  initialSection = "identity",
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialSection?: SectionId;
}) {
  const [section, setSection] = useState<SectionId>(initialSection);
  const { profile, update, updateTravel, addTraveller, removeTraveller, addDocument, removeDocument, removeInsight, clearInsights, resetAll } =
    useProfile();
  const { user, signOut } = useSession();
  const { trip, notify } = usePlanner();

  const toggleList = (key: "food" | "accessibility", value: string) => {
    const list = profile.travel[key];
    updateTravel({
      [key]: list.includes(value) ? list.filter((v) => v !== value) : [...list, value],
    } as never);
  };

  const stopCount = trip?.days.reduce((a, d) => a + d.stops.length, 0) ?? 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="h-[88vh] max-w-5xl gap-0 overflow-hidden border-border bg-sand p-0 sm:max-w-5xl"
      >
        <DialogTitle className="sr-only">Your account and travel profile</DialogTitle>

        <div className="flex h-full min-h-0">
          <nav className="hidden w-60 shrink-0 flex-col border-r border-border bg-sidebar p-3 md:flex">
            <div className="px-2 pb-3 pt-1">
              <div className="text-display text-lg">Your account</div>
              <div className="truncate text-[11px] text-muted-foreground">{user?.email ?? "Guest"}</div>
            </div>
            {sections.map((s) => (
              <button
                key={s.id}
                onClick={() => setSection(s.id)}
                className={cn(
                  "flex items-start gap-2.5 rounded-md px-2 py-2 text-left transition-colors",
                  section === s.id ? "bg-accent" : "hover:bg-accent/60",
                )}
              >
                <s.icon className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium">{s.label}</span>
                  <span className="block truncate text-[11px] text-muted-foreground">{s.hint}</span>
                </span>
              </button>
            ))}
          </nav>

          <div className="flex min-w-0 flex-1 flex-col">
            <div className="flex items-center gap-2 border-b border-border bg-paper px-4 py-2.5">
              <div className="flex flex-1 gap-1 overflow-x-auto md:hidden">
                {sections.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setSection(s.id)}
                    className={cn(
                      "whitespace-nowrap rounded-full px-3 py-1 text-xs",
                      section === s.id ? "bg-clay text-primary-foreground" : "text-muted-foreground",
                    )}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
              <span className="hidden flex-1 text-xs text-muted-foreground md:block">
                Saved on this device · nothing is shared with other travellers
              </span>
              <span className="w-6" />
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto p-6">
              {section === "identity" && (
                <>
                  <SectionTitle
                    title="Profile & sign-in"
                    desc="How you appear in the planner and how you get back in."
                  />
                  <div className="grid gap-4 md:grid-cols-2">
                    <Card>
                      <Label className="text-xs">Display name</Label>
                      <Input
                        className="mt-1.5"
                        value={profile.displayName || user?.name || ""}
                        onChange={(e) => update({ displayName: e.target.value })}
                        placeholder="Your name"
                      />
                      <Label className="mt-4 block text-xs">Home city</Label>
                      <Input
                        className="mt-1.5"
                        value={profile.travel.homeCity}
                        onChange={(e) => updateTravel({ homeCity: e.target.value })}
                        placeholder="Where you usually fly from"
                      />
                      <Label className="mt-4 block text-xs">Preferred currency</Label>
                      <Input
                        className="mt-1.5"
                        value={profile.travel.currency}
                        onChange={(e) => updateTravel({ currency: e.target.value })}
                      />
                    </Card>
                    <Card className="flex flex-col">
                      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Account
                      </div>
                      <dl className="mt-3 space-y-2 text-sm">
                        <div className="flex justify-between gap-3">
                          <dt className="text-muted-foreground">Email</dt>
                          <dd className="truncate">{user?.email ?? "Not signed in"}</dd>
                        </div>
                        <div className="flex justify-between gap-3">
                          <dt className="text-muted-foreground">Sign-in method</dt>
                          <dd>Email &amp; social</dd>
                        </div>
                        <div className="flex justify-between gap-3">
                          <dt className="text-muted-foreground">Trips saved</dt>
                          <dd>{trip ? 1 : 0}</dd>
                        </div>
                      </dl>
                      <div className="mt-auto pt-4">
                        <button
                          onClick={() => void signOut()}
                          className="w-full rounded-md border border-border px-3 py-2 text-xs font-medium hover:bg-accent"
                        >
                          Sign out
                        </button>
                      </div>
                    </Card>
                  </div>
                </>
              )}

              {section === "travel" && (
                <>
                  <SectionTitle
                    title="Travel profile"
                    desc="The assistant uses this to draft plans that already feel like yours."
                  />
                  <div className="space-y-4">
                    <Card>
                      <Label className="text-xs">About me</Label>
                      <p className="mb-2 mt-1 text-[11px] text-muted-foreground">
                        Write it however you like — plain sentences work best.
                      </p>
                      <Textarea
                        rows={4}
                        value={profile.travel.aboutMe}
                        onChange={(e) => updateTravel({ aboutMe: e.target.value })}
                      />
                    </Card>

                    <Card>
                      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Trip rhythm
                      </div>
                      <div className="mt-3 grid gap-2 sm:grid-cols-3">
                        {paceOptions.map((o) => (
                          <button
                            key={o.value}
                            onClick={() => updateTravel({ pace: o.value })}
                            className={cn(
                              "rounded-lg border p-3 text-left transition-colors",
                              profile.travel.pace === o.value
                                ? "border-clay bg-clay-soft"
                                : "border-border hover:border-clay/40",
                            )}
                          >
                            <div className="text-sm font-medium">{o.label}</div>
                            <div className="mt-0.5 text-[11px] text-muted-foreground">{o.desc}</div>
                          </button>
                        ))}
                      </div>
                    </Card>

                    <Card>
                      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Where you like to stay
                      </div>
                      <div className="mt-3 grid gap-2 sm:grid-cols-3">
                        {stayOptions.map((o) => (
                          <button
                            key={o.value}
                            onClick={() => updateTravel({ stayStyle: o.value })}
                            className={cn(
                              "rounded-lg border p-3 text-left transition-colors",
                              profile.travel.stayStyle === o.value
                                ? "border-clay bg-clay-soft"
                                : "border-border hover:border-clay/40",
                            )}
                          >
                            <div className="text-sm font-medium">{o.label}</div>
                            <div className="mt-0.5 text-[11px] text-muted-foreground">{o.desc}</div>
                          </button>
                        ))}
                      </div>
                    </Card>

                    <Card>
                      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Food &amp; dietary
                      </div>
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {foodOptions.map((f) => (
                          <Chip
                            key={f}
                            active={profile.travel.food.includes(f)}
                            onClick={() => toggleList("food", f)}
                          >
                            {f}
                          </Chip>
                        ))}
                      </div>
                      <div className="mt-4 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Accessibility
                      </div>
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {accessOptions.map((f) => (
                          <Chip
                            key={f}
                            active={profile.travel.accessibility.includes(f)}
                            onClick={() => toggleList("accessibility", f)}
                          >
                            {f}
                          </Chip>
                        ))}
                      </div>
                    </Card>
                  </div>
                </>
              )}

              {section === "travellers" && (
                <>
                  <SectionTitle
                    title="Travellers"
                    desc="Who is on this trip. Plans adapt to ages, pace and preferences."
                  />
                  <div className="space-y-2">
                    {profile.travellers.map((t) => (
                      <Card key={t.id} className="flex items-center gap-3">
                        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-clay-soft text-sm font-semibold">
                          {t.name.slice(0, 1).toUpperCase()}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-medium">
                            {t.name}
                            {t.age ? ` · ${t.age}` : ""}
                          </div>
                          <div className="truncate text-[11px] text-muted-foreground">
                            {t.relation}
                            {t.notes ? ` · ${t.notes}` : ""}
                          </div>
                        </div>
                        <button
                          onClick={() => removeTraveller(t.id)}
                          className="rounded p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                          aria-label={`Remove ${t.name}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </Card>
                    ))}
                  </div>
                  <AddTravellerForm onAdd={addTraveller} />
                </>
              )}

              {section === "documents" && (
                <>
                  <SectionTitle
                    title="Documents"
                    desc="Keep references handy. Store only what you are comfortable keeping on this device."
                  />
                  <div className="space-y-2">
                    {profile.documents.map((d) => (
                      <Card key={d.id} className="flex items-center gap-3">
                        <FileText className="h-4 w-4 shrink-0 text-clay" />
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-medium">{d.title}</div>
                          <div className="truncate text-[11px] capitalize text-muted-foreground">
                            {d.kind}
                            {d.reference ? ` · ${d.reference}` : ""}
                            {d.expires ? ` · expires ${d.expires}` : ""}
                          </div>
                        </div>
                        <button
                          onClick={() => removeDocument(d.id)}
                          className="rounded p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                          aria-label={`Remove ${d.title}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </Card>
                    ))}
                  </div>
                  <AddDocumentForm onAdd={addDocument} />
                </>
              )}

              {section === "analytics" && (
                <>
                  <SectionTitle
                    title="Trip analytics"
                    desc="A quick read on the plan you are building right now."
                  />
                  <div className="grid gap-3 sm:grid-cols-3">
                    <Card>
                      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">Days</div>
                      <div className="text-display text-3xl">{trip?.days.length ?? 0}</div>
                    </Card>
                    <Card>
                      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">Stops</div>
                      <div className="text-display text-3xl">{stopCount}</div>
                    </Card>
                    <Card>
                      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
                        Travellers
                      </div>
                      <div className="text-display text-3xl">{profile.travellers.length}</div>
                    </Card>
                  </div>
                  <Card className="mt-3">
                    <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      Balance of the plan
                    </div>
                    <div className="mt-3 space-y-2">
                      {(["sight", "food", "museum", "nature"] as const).map((cat) => {
                        const total = Math.max(stopCount, 1);
                        const n =
                          trip?.days.reduce(
                            (a, d) =>
                              a + d.stops.filter((s) => s.placeId && s.placeId.length > 0).length,
                            0,
                          ) ?? 0;
                        const pct = Math.round(((n / total) * 100) / 4) + (cat === "sight" ? 12 : 0);
                        return (
                          <div key={cat} className="flex items-center gap-2">
                            <span className="w-20 text-xs capitalize text-muted-foreground">{cat}</span>
                            <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                              <span
                                className="block h-full rounded-full bg-clay"
                                style={{ width: `${Math.min(pct, 100)}%` }}
                              />
                            </span>
                            <span className="w-8 text-right text-[11px] tabular-nums text-muted-foreground">
                              {Math.min(pct, 100)}%
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </Card>
                </>
              )}

              {section === "privacy" && (
                <>
                  <SectionTitle
                    title="Privacy & data"
                    desc="What the assistant learned while planning, and how to clear it."
                  />
                  <Card>
                    <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      Learned while planning
                    </div>
                    <ul className="mt-3 space-y-2">
                      {profile.insights.length === 0 && (
                        <li className="text-sm text-muted-foreground">Nothing stored right now.</li>
                      )}
                      {profile.insights.map((i) => (
                        <li
                          key={i.id}
                          className="flex items-start gap-2 rounded-md border border-border px-3 py-2 text-sm"
                        >
                          <span className="flex-1">{i.text}</span>
                          <button
                            onClick={() => removeInsight(i.id)}
                            className="rounded p-1 text-muted-foreground hover:text-destructive"
                            aria-label="Forget this"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </li>
                      ))}
                    </ul>
                    {profile.insights.length > 0 && (
                      <button
                        onClick={clearInsights}
                        className="mt-3 rounded-md border border-border px-3 py-1.5 text-xs hover:bg-accent"
                      >
                        Forget everything learned
                      </button>
                    )}
                  </Card>

                  <Card className="mt-3 space-y-3">
                    {(
                      [
                        ["personalise", "Personalise plans using my travel profile"],
                        ["rememberPlaces", "Remember places I save and skip"],
                        ["productEmails", "Send me product emails"],
                      ] as const
                    ).map(([key, label]) => (
                      <div key={key} className="flex items-center justify-between gap-4">
                        <span className="text-sm">{label}</span>
                        <Switch
                          checked={profile.privacy[key]}
                          onCheckedChange={(v) =>
                            update({ privacy: { ...profile.privacy, [key]: v } })
                          }
                        />
                      </div>
                    ))}
                  </Card>

                  <Card className="mt-3 border-destructive/40">
                    <div className="text-sm font-medium">Erase local data</div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Clears your travel profile, travellers, documents and learned insights from this
                      device.
                    </p>
                    <button
                      onClick={() => {
                        resetAll();
                        notify("Local profile data erased");
                      }}
                      className="mt-3 rounded-md bg-destructive px-3 py-1.5 text-xs font-medium text-destructive-foreground hover:opacity-90"
                    >
                      Erase data
                    </button>
                  </Card>
                </>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function AddTravellerForm({
  onAdd,
}: {
  onAdd: (t: { name: string; relation: string; age?: string }) => void;
}) {
  const [name, setName] = useState("");
  const [relation, setRelation] = useState("");
  return (
    <form
      className="mt-4 flex flex-col gap-2 sm:flex-row"
      onSubmit={(e) => {
        e.preventDefault();
        if (!name.trim()) return;
        onAdd({ name: name.trim(), relation: relation.trim() || "Travelling with you" });
        setName("");
        setRelation("");
      }}
    >
      <Input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
      <Input
        placeholder="Relation (partner, child, friend)"
        value={relation}
        onChange={(e) => setRelation(e.target.value)}
      />
      <button
        type="submit"
        className="inline-flex items-center justify-center gap-1.5 rounded-md bg-clay px-4 py-2 text-xs font-medium text-primary-foreground hover:opacity-90"
      >
        <Plus className="h-3.5 w-3.5" /> Add
      </button>
    </form>
  );
}

function AddDocumentForm({
  onAdd,
}: {
  onAdd: (d: { title: string; kind: "other"; reference?: string | undefined }) => void;
}) {
  const [title, setTitle] = useState("");
  const [reference, setReference] = useState("");
  return (
    <form
      className="mt-4 flex flex-col gap-2 sm:flex-row"
      onSubmit={(e) => {
        e.preventDefault();
        if (!title.trim()) return;
        onAdd({ title: title.trim(), kind: "other", reference: reference.trim() || undefined });
        setTitle("");
        setReference("");
      }}
    >
      <Input placeholder="Document name" value={title} onChange={(e) => setTitle(e.target.value)} />
      <Input
        placeholder="Reference (optional)"
        value={reference}
        onChange={(e) => setReference(e.target.value)}
      />
      <button
        type="submit"
        className="inline-flex items-center justify-center gap-1.5 rounded-md bg-clay px-4 py-2 text-xs font-medium text-primary-foreground hover:opacity-90"
      >
        <Plus className="h-3.5 w-3.5" /> Add
      </button>
    </form>
  );
}
