import { useState } from "react";
import {
  ChevronDown,
  Clock,
  Footprints,
  GripVertical,
  Plus,
  Train,
  Trash2,
  Wallet,
} from "lucide-react";
import { placesById } from "@/data/trips";
import { usePlanner } from "@/lib/planner-store";
import { cn } from "@/lib/utils";
import { CategoryIcon } from "@/components/PlaceThumb";
import { TripSnapshot } from "./TripSnapshot";

function minutesLabel(m: number) {
  const h = Math.floor(m / 60);
  const r = m % 60;
  return h ? `${h}h${r ? ` ${r}m` : ""}` : `${r}m`;
}

export function ItineraryRail() {
  const {
    trip,
    dayId,
    selectDay,
    selectedPlaceId,
    selectPlace,
    setHoveredStopId,
    moveStop,
    removeStop,
  } = usePlanner();
  const [dragIndex, setDragIndex] = useState<number | null>(null);

  if (!trip) {
    return (
      <div className="flex h-full flex-col">
        <TripSnapshot />
        <div className="flex flex-1 items-center justify-center p-6 text-center text-sm text-muted-foreground">
          No trip open yet.
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col bg-sidebar">
      <TripSnapshot />

      <div className="flex-1 overflow-y-auto px-2 pb-6">
        {trip.days.length === 0 ? (
          <div className="mx-2 mt-4 rounded-lg border border-dashed border-border p-5 text-center">
            <p className="text-display text-lg">A blank canvas</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Describe the trip in the chat below and the first draft appears here.
            </p>
          </div>
        ) : (
          trip.days.map((day, dayIdx) => {
            const open = day.id === dayId;
            const total = day.stops.reduce(
              (acc, s) => acc + s.durationMinutes + (s.travelToNextMinutes ?? 0),
              0,
            );
            const travel = day.stops.reduce((acc, s) => acc + (s.travelToNextMinutes ?? 0), 0);

            return (
              <section key={day.id} className="mt-2">
                <button
                  onClick={() => selectDay(day.id)}
                  className={cn(
                    "flex w-full items-center gap-2 rounded-md px-2 py-2 text-left transition-colors",
                    open ? "bg-accent" : "hover:bg-accent/60",
                  )}
                >
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-clay text-[11px] font-semibold text-primary-foreground">
                    {dayIdx + 1}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium">{day.title}</span>
                    <span className="block text-[11px] text-muted-foreground">{day.date}</span>
                  </span>
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 shrink-0 text-muted-foreground transition-transform",
                      open && "rotate-180",
                    )}
                  />
                </button>

                {open && (
                  <ol className="mt-1 space-y-1 pl-2">
                    {day.stops.map((stop, i) => {
                      const place = placesById[stop.placeId];
                      if (!place) return null;
                      const active = place.id === selectedPlaceId;
                      return (
                        <li key={stop.id}>
                          <div
                            draggable
                            onDragStart={() => setDragIndex(i)}
                            onDragOver={(e) => e.preventDefault()}
                            onDrop={() => {
                              if (dragIndex !== null && dragIndex !== i)
                                moveStop(day.id, dragIndex, i);
                              setDragIndex(null);
                            }}
                            onMouseEnter={() => setHoveredStopId(stop.id)}
                            onMouseLeave={() => setHoveredStopId(null)}
                            onClick={() => selectPlace(place.id)}
                            className={cn(
                              "group flex cursor-pointer items-start gap-2 rounded-md border px-2 py-2 transition-colors",
                              active
                                ? "border-clay/40 bg-paper shadow-paper"
                                : "border-transparent hover:border-border hover:bg-paper/70",
                            )}
                          >
                            <GripVertical className="mt-0.5 h-4 w-4 shrink-0 cursor-grab text-muted-foreground/50 opacity-0 transition-opacity group-hover:opacity-100" />
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5 text-[11px] tabular-nums text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                {stop.startTime}
                                <span aria-hidden>·</span>
                                {minutesLabel(stop.durationMinutes)}
                              </div>
                              <div className="mt-0.5 flex items-center gap-1.5">
                                <CategoryIcon
                                  category={place.category}
                                  className="h-3.5 w-3.5 shrink-0 text-clay"
                                />
                                <span className="truncate text-sm font-medium">{place.name}</span>
                              </div>
                              {stop.note && (
                                <p className="mt-1 line-clamp-2 text-[11px] italic text-muted-foreground">
                                  {stop.note}
                                </p>
                              )}
                            </div>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                removeStop(day.id, stop.id);
                              }}
                              className="mt-0.5 rounded p-1 text-muted-foreground/60 opacity-0 transition-opacity hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                              aria-label={`Remove ${place.name}`}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>

                          {stop.travelToNextMinutes ? (
                            <div className="ml-6 flex items-center gap-1.5 py-1 text-[11px] text-muted-foreground">
                              {stop.travelMode === "metro" ? (
                                <Train className="h-3 w-3" />
                              ) : (
                                <Footprints className="h-3 w-3" />
                              )}
                              {stop.travelToNextMinutes} min{" "}
                              {stop.travelMode === "metro" ? "by train" : "walk"}
                            </div>
                          ) : null}
                        </li>
                      );
                    })}

                    <li className="flex items-center justify-between rounded-md bg-accent/50 px-2 py-1.5 text-[11px] text-muted-foreground">
                      <span className="inline-flex items-center gap-1.5">
                        <Clock className="h-3 w-3" /> {minutesLabel(total)} planned ·{" "}
                        {minutesLabel(travel)} moving
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <Wallet className="h-3 w-3" /> ~¥{(day.stops.length * 1400).toLocaleString()}
                      </span>
                    </li>
                  </ol>
                )}
              </section>
            );
          })
        )}

        <button className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-border px-2 py-2 text-xs text-muted-foreground transition-colors hover:border-clay/50 hover:text-foreground">
          <Plus className="h-3.5 w-3.5" /> Add a day
        </button>
      </div>
    </div>
  );
}
