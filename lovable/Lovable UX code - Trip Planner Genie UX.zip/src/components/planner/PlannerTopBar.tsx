import { Check, Compass, LogOut, Plus, Settings, Sparkles } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { usePlanner } from "@/lib/planner-store";
import { useSession } from "@/lib/session";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export type PlannerView = "split" | "plan" | "map" | "guide";

const views: { id: PlannerView; label: string }[] = [
  { id: "split", label: "Workspace" },
  { id: "plan", label: "Itinerary" },
  { id: "map", label: "Map" },
  { id: "guide", label: "Guide" },
];

export function PlannerTopBar({
  view,
  onViewChange,
  onOpenProfile,
}: {
  view: PlannerView;
  onViewChange: (view: PlannerView) => void;
  onOpenProfile: () => void;
}) {
  const { notice, createTrip } = usePlanner();
  const { user, signOut } = useSession();

  return (
    <header className="flex h-12 shrink-0 items-center gap-3 border-b border-border bg-paper px-3">
      <Link to="/" className="inline-flex items-center gap-2">
        <Compass className="h-4 w-4 text-clay" />
        <span className="text-display text-base">AI Trip Planner</span>
      </Link>

      <div className="hidden items-center gap-0.5 rounded-full border border-border bg-sand p-0.5 md:flex">
        {views.map((v) => (
          <button
            key={v.id}
            onClick={() => onViewChange(v.id)}
            className={cn(
              "rounded-full px-3 py-1 text-xs transition-colors",
              view === v.id
                ? "bg-paper font-medium text-foreground shadow-paper"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            {v.label}
          </button>
        ))}
      </div>

      <div className="flex flex-1 justify-center">
        {notice && (
          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-sand px-3 py-1 text-[11px] text-muted-foreground">
            <Check className="h-3 w-3 text-sage" />
            {notice}
          </span>
        )}
      </div>

      <button
        onClick={() => createTrip("New trip")}
        className="hidden items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-xs font-medium hover:bg-accent sm:inline-flex"
      >
        <Plus className="h-3.5 w-3.5 text-clay" /> New trip
      </button>

      {user ? (
        <DropdownMenu>
          <DropdownMenuTrigger className="flex items-center gap-2 rounded-full border border-border py-1 pl-1 pr-3 text-xs hover:bg-accent">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-clay text-[11px] font-semibold uppercase text-primary-foreground">
              {user.name.slice(0, 1)}
            </span>
            <span className="max-w-24 truncate">{user.name}</span>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">
              {user.email}
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={onOpenProfile} className="gap-2 text-xs">
              <Settings className="h-3.5 w-3.5" /> Profile &amp; settings
            </DropdownMenuItem>
            <DropdownMenuItem onSelect={onOpenProfile} className="gap-2 text-xs">
              <Sparkles className="h-3.5 w-3.5" /> Travel profile
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={() => void signOut()} className="gap-2 text-xs">
              <LogOut className="h-3.5 w-3.5" /> Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ) : (
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenProfile}
            className="rounded-full border border-border p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Open settings"
          >
            <Settings className="h-4 w-4" />
          </button>
          <Link
            to="/auth"
            className="rounded-full bg-clay px-3 py-1.5 text-xs font-medium text-primary-foreground transition-opacity hover:opacity-90"
          >
            Sign in
          </Link>
        </div>
      )}
    </header>
  );
}
