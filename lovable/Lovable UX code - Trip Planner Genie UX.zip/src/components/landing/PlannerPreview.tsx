import { Clock, MapPin, Sparkles, Star } from "lucide-react";

const previewStops = [
  { time: "06:50", name: "Fushimi Inari sunrise", meta: "2h · free" },
  { time: "10:30", name: "Kinkaku-ji", meta: "1h · ¥500" },
  { time: "13:00", name: "Nishiki Market lunch", meta: "1h 15m · ¥¥" },
  { time: "17:30", name: "Gion lantern walk", meta: "1h 30m · free" },
];

/** Non-interactive miniature of the real planner, used as landing-page proof. */
export function PlannerPreview() {
  return (
    <div
      aria-hidden
      className="overflow-hidden rounded-xl border border-border bg-paper shadow-lift"
    >
      <div className="flex items-center gap-2 border-b border-border px-3 py-2">
        <span className="flex gap-1">
          <i className="block h-2 w-2 rounded-full bg-clay-soft" />
          <i className="block h-2 w-2 rounded-full bg-accent" />
          <i className="block h-2 w-2 rounded-full bg-sage-soft" />
        </span>
        <span className="mx-auto rounded-full bg-sand px-2.5 py-0.5 text-[10px] text-muted-foreground">
          Kyoto in cherry season · Day 2 saved
        </span>
      </div>

      <div className="grid h-[300px] grid-cols-[34%_1fr] sm:grid-cols-[26%_1fr_28%]">
        <div className="border-r border-border bg-sidebar p-2">
          <p className="px-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            Day 2 · Tue 15 Apr
          </p>
          <ul className="mt-2 space-y-1.5">
            {previewStops.map((s, i) => (
              <li
                key={s.name}
                className={`rounded-md border px-2 py-1.5 ${
                  i === 0 ? "border-clay/40 bg-paper" : "border-transparent"
                }`}
              >
                <span className="flex items-center gap-1 text-[9px] tabular-nums text-muted-foreground">
                  <Clock className="h-2.5 w-2.5" /> {s.time}
                </span>
                <span className="mt-0.5 block truncate text-[11px] font-medium">{s.name}</span>
                <span className="block text-[9px] text-muted-foreground">{s.meta}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="relative bg-sand">
          <div className="absolute inset-0 opacity-70 [background-image:linear-gradient(oklch(0.888_0.017_85)_1px,transparent_1px),linear-gradient(90deg,oklch(0.888_0.017_85)_1px,transparent_1px)] [background-size:26px_26px]" />
          <svg className="absolute inset-0 h-full w-full" viewBox="0 0 300 300" fill="none">
            <path
              d="M60 220 C110 200 120 140 170 120 S250 90 250 60"
              stroke="oklch(0.556 0.146 39)"
              strokeWidth="2"
              strokeDasharray="6 6"
              opacity="0.7"
            />
          </svg>
          {[
            [60, 220],
            [170, 120],
            [250, 60],
            [120, 150],
          ].map(([x, y], i) => (
            <span
              key={i}
              className="absolute flex h-6 w-6 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-2 border-paper bg-clay text-[10px] font-semibold text-primary-foreground shadow-paper"
              style={{ left: `${((x as number) / 300) * 100}%`, top: `${((y as number) / 300) * 100}%` }}
            >
              {i + 1}
            </span>
          ))}
          <span className="absolute bottom-2 left-2 inline-flex items-center gap-1 rounded-full border border-border bg-paper/90 px-2 py-0.5 text-[9px] text-muted-foreground">
            <MapPin className="h-2.5 w-2.5" /> 4 stops · 3.1 km walking
          </span>
        </div>

        <div className="hidden border-l border-border p-2 sm:block">
          <div className="h-16 rounded-md bg-linear-to-br from-clay-soft to-clay/60" />
          <p className="mt-2 text-[11px] font-medium leading-tight">Fushimi Inari Taisha</p>
          <p className="mt-0.5 flex items-center gap-1 text-[9px] text-muted-foreground">
            <Star className="h-2.5 w-2.5 fill-ochre text-ochre" /> 4.8 · 48,213 reviews
          </p>
          <dl className="mt-2 space-y-1 text-[9px] text-muted-foreground">
            <div className="flex justify-between">
              <dt>Open</dt>
              <dd>24 hours</dd>
            </div>
            <div className="flex justify-between">
              <dt>Ticket</dt>
              <dd>Free</dd>
            </div>
            <div className="flex justify-between">
              <dt>Typical visit</dt>
              <dd>2 h</dd>
            </div>
          </dl>
        </div>
      </div>

      <div className="flex items-center gap-2 border-t border-border px-3 py-2">
        <Sparkles className="h-3 w-3 text-clay" />
        <span className="truncate text-[10px] text-muted-foreground">
          “Make day 2 lighter and add a market lunch” — assistant rebalanced 3 stops
        </span>
      </div>
    </div>
  );
}
