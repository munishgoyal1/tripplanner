import { useEffect, useRef, useState } from "react";
import { Pause, Play, RotateCcw, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

type Step =
  | { kind: "user"; text: string }
  | { kind: "agent"; text: string; chips?: string[] }
  | { kind: "event"; text: string };

const script: Step[] = [
  { kind: "user", text: "Kyoto for 4 days in April with a 7-year-old. Nothing too packed." },
  { kind: "event", text: "Reading your travel profile · balanced pace · walkable stays" },
  {
    kind: "agent",
    text: "Drafted 4 days around three neighbourhood clusters, with an early Fushimi Inari start and a slow afternoon on day two.",
    chips: ["4 days", "16 stops", "0 clashes"],
  },
  { kind: "user", text: "Day 3 looks heavy. And we need a lunch stop." },
  { kind: "event", text: "Checking opening hours and travel times" },
  {
    kind: "agent",
    text: "Removed the second temple, moved Arashiyama earlier, and added a counter-seat lunch nine minutes from your midday cluster.",
    chips: ["−1 stop", "+ Nishiki Market", "−22 min travel"],
  },
  { kind: "user", text: "Rain on Thursday?" },
  {
    kind: "agent",
    text: "Afternoon showers forecast. Swapped the garden walk for the covered arcade and kept your dinner plan intact.",
    chips: ["Weather-aware", "1 swap"],
  },
  { kind: "event", text: "Itinerary saved · ready to follow" },
];

export function AgentReplay() {
  const [index, setIndex] = useState(1);
  const [playing, setPlaying] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!playing) return;
    const t = window.setTimeout(() => {
      setIndex((i) => {
        if (i >= script.length) {
          setPlaying(false);
          return i;
        }
        return i + 1;
      });
    }, 1500);
    return () => window.clearTimeout(t);
  }, [playing, index]);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [index]);

  const done = index >= script.length;

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-paper shadow-paper">
      <div className="flex items-center gap-2 border-b border-border bg-sand px-4 py-2.5">
        <Sparkles className="h-4 w-4 text-clay" />
        <span className="text-xs font-medium">Agent replay — a real planning session</span>
        <div className="ml-auto flex items-center gap-1">
          <button
            onClick={() => {
              if (done) setIndex(1);
              setPlaying((p) => !p);
            }}
            className="inline-flex items-center gap-1.5 rounded-full bg-clay px-3 py-1 text-[11px] font-medium text-primary-foreground hover:opacity-90"
          >
            {playing ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
            {playing ? "Pause" : done ? "Replay" : "Play"}
          </button>
          <button
            onClick={() => {
              setPlaying(false);
              setIndex(1);
            }}
            className="rounded-full border border-border p-1.5 text-muted-foreground hover:text-foreground"
            aria-label="Restart replay"
          >
            <RotateCcw className="h-3 w-3" />
          </button>
        </div>
      </div>

      <div ref={scroller} className="max-h-80 space-y-3 overflow-y-auto p-4">
        {script.slice(0, index).map((s, i) => (
          <div
            key={i}
            className={cn(
              "flex",
              s.kind === "user" ? "justify-end" : s.kind === "event" ? "justify-center" : "justify-start",
            )}
          >
            {s.kind === "event" ? (
              <span className="rounded-full border border-border bg-sand px-3 py-1 text-[11px] text-muted-foreground">
                {s.text}
              </span>
            ) : (
              <div
                className={cn(
                  "max-w-[80%] rounded-xl px-3 py-2 text-sm leading-relaxed",
                  s.kind === "user"
                    ? "bg-clay text-primary-foreground"
                    : "border border-border bg-sand",
                )}
              >
                {s.text}
                {"chips" in s && s.chips && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {s.chips.map((c) => (
                      <span
                        key={c}
                        className="rounded-full border border-border bg-paper px-2 py-0.5 text-[10px] text-muted-foreground"
                      >
                        {c}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
        {playing && !done && (
          <div className="flex justify-start">
            <span className="rounded-xl border border-border bg-sand px-3 py-2 text-xs text-muted-foreground">
              thinking…
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
