import { Camera, Landmark, Leaf, Moon, ShoppingBag, Train, Utensils, BedDouble } from "lucide-react";
import { cn } from "@/lib/utils";
import type { PlaceCategory } from "@/data/types";

const icons: Record<PlaceCategory, typeof Landmark> = {
  sight: Landmark,
  museum: Camera,
  food: Utensils,
  nature: Leaf,
  shopping: ShoppingBag,
  nightlife: Moon,
  stay: BedDouble,
  transit: Train,
};

const swatches: Record<string, string> = {
  clay: "from-clay-soft to-clay/70",
  sage: "from-sage-soft to-sage/70",
  ochre: "from-accent to-ochre/70",
};

export function CategoryIcon({
  category,
  className,
}: {
  category: PlaceCategory;
  className?: string;
}) {
  const Icon = icons[category] ?? Landmark;
  return <Icon className={cn("h-4 w-4", className)} aria-hidden />;
}

export function PlaceThumb({
  category,
  swatch = "clay",
  className,
  size = "md",
}: {
  category: PlaceCategory;
  swatch?: string;
  className?: string;
  size?: "sm" | "md" | "lg";
}) {
  return (
    <div
      className={cn(
        "grain relative flex items-center justify-center overflow-hidden rounded-md bg-linear-to-br text-clay",
        swatches[swatch] ?? swatches["clay"],
        size === "sm" && "h-9 w-9",
        size === "md" && "h-14 w-14",
        size === "lg" && "h-full w-full rounded-lg",
        className,
      )}
      aria-hidden
    >
      <CategoryIcon
        category={category}
        className={cn(size === "lg" ? "h-8 w-8" : size === "md" ? "h-5 w-5" : "h-4 w-4", "opacity-70")}
      />
    </div>
  );
}
