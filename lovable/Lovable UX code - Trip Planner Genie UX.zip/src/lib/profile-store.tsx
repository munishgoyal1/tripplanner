import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export type TripPace = "relaxed" | "balanced" | "see_it_all";
export type StayStyle = "walkable" | "quiet" | "value";

export interface Traveller {
  id: string;
  name: string;
  relation: string;
  age?: string | undefined;
  notes?: string | undefined;
}

export interface TravelDocument {
  id: string;
  title: string;
  kind: "passport" | "visa" | "insurance" | "booking" | "other";
  reference?: string | undefined;
  expires?: string | undefined;
}

export interface LearnedInsight {
  id: string;
  text: string;
}

export interface TravelProfile {
  aboutMe: string;
  pace: TripPace;
  stayStyle: StayStyle;
  food: string[];
  accessibility: string[];
  homeCity: string;
  currency: string;
}

export interface ProfileState {
  displayName: string;
  travel: TravelProfile;
  travellers: Traveller[];
  documents: TravelDocument[];
  insights: LearnedInsight[];
  privacy: {
    personalise: boolean;
    rememberPlaces: boolean;
    productEmails: boolean;
  };
}

const STORAGE_KEY = "atp.profile.v1";

export const defaultProfile: ProfileState = {
  displayName: "",
  travel: {
    aboutMe:
      "I travel with my partner and our seven-year-old. We like mornings out early, a long lunch, and one unhurried thing in the evening.",
    pace: "balanced",
    stayStyle: "walkable",
    food: ["Vegetarian friendly", "No shellfish"],
    accessibility: ["Stroller friendly"],
    homeCity: "Bengaluru, India",
    currency: "INR",
  },
  travellers: [
    { id: "t1", name: "You", relation: "Primary traveller" },
    { id: "t2", name: "Priya", relation: "Partner", notes: "Prefers slower mornings" },
    { id: "t3", name: "Aarav", relation: "Child", age: "7", notes: "Naps after lunch" },
  ],
  documents: [
    { id: "d1", title: "Passport — You", kind: "passport", reference: "•••• 4821", expires: "Mar 2031" },
    { id: "d2", title: "Japan eVisa", kind: "visa", reference: "•••• 7730", expires: "Nov 2026" },
    { id: "d3", title: "Travel insurance", kind: "insurance", reference: "Policy •••• 118" },
  ],
  insights: [
    { id: "i1", text: "Prefers walkable neighbourhoods over cheaper stays further out." },
    { id: "i2", text: "Avoids more than two museums in a single day." },
    { id: "i3", text: "Likes one food-market stop per city." },
  ],
  privacy: { personalise: true, rememberPlaces: true, productEmails: false },
};

interface ProfileValue {
  profile: ProfileState;
  update: (patch: Partial<ProfileState>) => void;
  updateTravel: (patch: Partial<TravelProfile>) => void;
  addTraveller: (t: Omit<Traveller, "id">) => void;
  removeTraveller: (id: string) => void;
  addDocument: (d: Omit<TravelDocument, "id">) => void;
  removeDocument: (id: string) => void;
  removeInsight: (id: string) => void;
  clearInsights: () => void;
  resetAll: () => void;
}

const ProfileContext = createContext<ProfileValue | null>(null);

let seq = 0;
const uid = (p: string) => `${p}-${Date.now().toString(36)}-${++seq}`;

export function ProfileProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<ProfileState>(defaultProfile);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setProfile({ ...defaultProfile, ...(JSON.parse(raw) as ProfileState) });
    } catch {
      /* ignore corrupt local state */
    }
  }, []);

  const persist = useCallback((next: ProfileState) => {
    setProfile(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* storage unavailable */
    }
  }, []);

  const value = useMemo<ProfileValue>(() => {
    const mutate = (fn: (p: ProfileState) => ProfileState) =>
      setProfile((prev) => {
        const next = fn(prev);
        try {
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
        } catch {
          /* storage unavailable */
        }
        return next;
      });

    return {
      profile,
      update: (patch) => mutate((p) => ({ ...p, ...patch })),
      updateTravel: (patch) => mutate((p) => ({ ...p, travel: { ...p.travel, ...patch } })),
      addTraveller: (t) => mutate((p) => ({ ...p, travellers: [...p.travellers, { ...t, id: uid("t") }] })),
      removeTraveller: (id) =>
        mutate((p) => ({ ...p, travellers: p.travellers.filter((t) => t.id !== id) })),
      addDocument: (d) => mutate((p) => ({ ...p, documents: [...p.documents, { ...d, id: uid("d") }] })),
      removeDocument: (id) =>
        mutate((p) => ({ ...p, documents: p.documents.filter((d) => d.id !== id) })),
      removeInsight: (id) => mutate((p) => ({ ...p, insights: p.insights.filter((i) => i.id !== id) })),
      clearInsights: () => mutate((p) => ({ ...p, insights: [] })),
      resetAll: () => persist(defaultProfile),
    };
  }, [profile, persist]);

  return <ProfileContext.Provider value={value}>{children}</ProfileContext.Provider>;
}

export function useProfile() {
  const ctx = useContext(ProfileContext);
  if (!ctx) throw new Error("useProfile must be used inside ProfileProvider");
  return ctx;
}
