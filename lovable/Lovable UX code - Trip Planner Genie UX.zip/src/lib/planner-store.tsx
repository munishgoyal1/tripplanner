import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { placesById, trips as seedTrips } from "@/data/trips";
import type { Day, Stop, Trip } from "@/data/types";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  chips?: string[];
}

let idCounter = 0;
const nextId = (prefix: string) => `${prefix}-${++idCounter}`;

interface PlannerValue {
  trips: Trip[];
  trip: Trip | undefined;
  tripId: string;
  selectDay: (dayId: string) => void;
  dayId: string | null;
  day: Day | undefined;
  selectedPlaceId: string | null;
  selectPlace: (placeId: string | null) => void;
  hoveredStopId: string | null;
  setHoveredStopId: (id: string | null) => void;
  selectTrip: (id: string) => void;
  createTrip: (name?: string, destination?: string) => void;
  deleteTrip: (id: string) => void;
  renameTrip: (id: string, name: string) => void;
  moveStop: (dayId: string, from: number, to: number) => void;
  removeStop: (dayId: string, stopId: string) => void;
  addPlaceToDay: (dayId: string, placeId: string) => void;
  notice: string | null;
  notify: (message: string) => void;
  messages: ChatMessage[];
  sendMessage: (text: string) => void;
  thinking: boolean;
}

const PlannerContext = createContext<PlannerValue | null>(null);

const cannedReplies: { match: RegExp; text: string; chips: string[] }[] = [
  {
    match: /light|slow|relax|less/i,
    text: "Trimmed that day to three stops and pushed the start to 09:30. The temple circuit now has a 90-minute buffer before dinner.",
    chips: ["Removed 1 stop", "Start 09:30", "Buffer +90 min"],
  },
  {
    match: /food|eat|restaurant|dinner|lunch/i,
    text: "Added a counter-seating lunch near your midday cluster and a riverside dinner within a 9-minute walk of your last stop.",
    chips: ["+ Nishiki Market", "+ Pontocho Kappa Sushi"],
  },
  {
    match: /rain|weather/i,
    text: "Rain is forecast for the afternoon. I swapped the garden walk for the covered arcade and kept the evening plan intact.",
    chips: ["Swapped 1 stop", "Weather-aware"],
  },
  {
    match: /swap|replace|instead/i,
    text: "Swapped it for a higher-rated option 400 m away that is open on that day. Travel time between stops dropped by 12 minutes.",
    chips: ["1 swap", "−12 min travel"],
  },
];

export function PlannerProvider({ children }: { children: ReactNode }) {
  const [trips, setTrips] = useState<Trip[]>(seedTrips);
  const [tripId, setTripId] = useState<string>(seedTrips[0]!.id);
  const [dayId, setDayId] = useState<string | null>(seedTrips[0]!.days[0]?.id ?? null);
  const [selectedPlaceId, setSelectedPlaceId] = useState<string | null>(
    seedTrips[0]!.days[0]?.stops[0]?.placeId ?? null,
  );
  const [hoveredStopId, setHoveredStopId] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>("All changes saved");
  const [thinking, setThinking] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "m0",
      role: "assistant",
      text: "Your Kyoto plan is drafted across four days. Ask me to rebalance a day, add food stops, or swap anything that does not fit.",
    },
  ]);

  const trip = trips.find((t) => t.id === tripId);
  const day = trip?.days.find((d) => d.id === dayId);

  const notify = useCallback((message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice("All changes saved"), 3200);
  }, []);

  const selectTrip = useCallback(
    (id: string) => {
      const target = trips.find((t) => t.id === id);
      setTripId(id);
      setDayId(target?.days[0]?.id ?? null);
      setSelectedPlaceId(target?.days[0]?.stops[0]?.placeId ?? null);
      notify(`Opened ${target?.name ?? "trip"}`);
    },
    [trips, notify],
  );

  const createTrip = useCallback(
    (name = "Untitled trip", destination = "Where to?") => {
      const id = nextId("trip");
      const trip: Trip = {
        id,
        name,
        destination,
        dateRange: "Dates to set",
        travelers: 1,
        cover: "sage",
        center: [20, 0],
        days: [],
      };
      setTrips((prev) => [trip, ...prev]);
      setTripId(id);
      setDayId(null);
      setSelectedPlaceId(null);
      notify("New trip created");
    },
    [notify],
  );

  const deleteTrip = useCallback(
    (id: string) => {
      setTrips((prev) => {
        const next = prev.filter((t) => t.id !== id);
        if (id === tripId) {
          const fallback = next[0];
          setTripId(fallback?.id ?? "");
          setDayId(fallback?.days[0]?.id ?? null);
          setSelectedPlaceId(fallback?.days[0]?.stops[0]?.placeId ?? null);
        }
        return next;
      });
      notify("Trip deleted");
    },
    [tripId, notify],
  );

  const renameTrip = useCallback(
    (id: string, name: string) => {
      setTrips((prev) => prev.map((t) => (t.id === id ? { ...t, name } : t)));
      notify("Trip renamed");
    },
    [notify],
  );

  const updateDay = useCallback(
    (targetDayId: string, fn: (day: Day) => Day) => {
      setTrips((prev) =>
        prev.map((t) =>
          t.id !== tripId
            ? t
            : { ...t, days: t.days.map((d) => (d.id === targetDayId ? fn(d) : d)) },
        ),
      );
    },
    [tripId],
  );

  const moveStop = useCallback(
    (targetDayId: string, from: number, to: number) => {
      updateDay(targetDayId, (d) => {
        const stops = [...d.stops];
        const [moved] = stops.splice(from, 1);
        if (!moved) return d;
        stops.splice(to, 0, moved);
        return { ...d, stops };
      });
      notify("Itinerary reordered · times recalculated");
    },
    [updateDay, notify],
  );

  const removeStop = useCallback(
    (targetDayId: string, stopId: string) => {
      updateDay(targetDayId, (d) => ({
        ...d,
        stops: d.stops.filter((s) => s.id !== stopId),
      }));
      notify("Stop removed from the day");
    },
    [updateDay, notify],
  );

  const addPlaceToDay = useCallback(
    (targetDayId: string, placeId: string) => {
      const place = placesById[placeId];
      if (!place) return;
      const stop: Stop = {
        id: nextId("stop"),
        placeId,
        startTime: "16:00",
        durationMinutes: place.typicalVisitMinutes,
      };
      updateDay(targetDayId, (d) => ({ ...d, stops: [...d.stops, stop] }));
      notify(`${place.name} added to the day`);
    },
    [updateDay, notify],
  );

  const sendMessage = useCallback((text: string) => {
    const userMsg: ChatMessage = { id: nextId("msg"), role: "user", text };
    setMessages((prev) => [...prev, userMsg]);
    setThinking(true);
    window.setTimeout(() => {
      const reply = cannedReplies.find((r) => r.match.test(text));
      setMessages((prev) => [
        ...prev,
        {
          id: nextId("msg"),
          role: "assistant",
          text:
            reply?.text ??
            "Updated the plan with that in mind. I kept travel between stops under 20 minutes and left the evening open.",
          chips: reply?.chips ?? ["Plan updated"],
        },
      ]);
      setThinking(false);
      setNotice("Itinerary updated by assistant");
      window.setTimeout(() => setNotice("All changes saved"), 3200);
    }, 900);
  }, []);

  const value = useMemo<PlannerValue>(
    () => ({
      trips,
      trip,
      tripId,
      dayId,
      day,
      selectDay: (id: string) => {
        setDayId(id);
        const target = trip?.days.find((d) => d.id === id);
        setSelectedPlaceId(target?.stops[0]?.placeId ?? null);
      },
      selectedPlaceId,
      selectPlace: setSelectedPlaceId,
      hoveredStopId,
      setHoveredStopId,
      selectTrip,
      createTrip,
      deleteTrip,
      renameTrip,
      moveStop,
      removeStop,
      addPlaceToDay,
      notice,
      notify,
      messages,
      sendMessage,
      thinking,
    }),
    [
      trips,
      trip,
      tripId,
      dayId,
      day,
      selectedPlaceId,
      hoveredStopId,
      selectTrip,
      createTrip,
      deleteTrip,
      renameTrip,
      moveStop,
      removeStop,
      addPlaceToDay,
      notice,
      notify,
      messages,
      sendMessage,
      thinking,
    ],
  );

  return <PlannerContext.Provider value={value}>{children}</PlannerContext.Provider>;
}

export function usePlanner() {
  const ctx = useContext(PlannerContext);
  if (!ctx) throw new Error("usePlanner must be used inside PlannerProvider");
  return ctx;
}
