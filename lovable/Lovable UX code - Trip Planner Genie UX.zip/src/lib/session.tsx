import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  avatarUrl: string | null;
}

interface SessionValue {
  user: SessionUser | null;
  loading: boolean;
  signOut: () => Promise<void>;
}

const SessionContext = createContext<SessionValue | null>(null);

function toUser(session: Session | null): SessionUser | null {
  if (!session?.user) return null;
  const meta = session.user.user_metadata ?? {};
  const email = session.user.email ?? "";
  const name =
    (meta['display_name'] as string) ||
    (meta['full_name'] as string) ||
    (meta['name'] as string) ||
    email.split("@")[0] ||
    "Traveller";
  return {
    id: session.user.id,
    name,
    email,
    avatarUrl: (meta['avatar_url'] as string) ?? null,
  };
}

export function SessionProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [loading, setLoading] = useState(true);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(toUser(session));
      setLoading(false);
    });
    void supabase.auth.getSession().then(({ data }) => {
      setUser(toUser(data.session));
      setLoading(false);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const signOut = useCallback(async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    setUser(null);
    navigate({ to: "/", replace: true });
  }, [queryClient, navigate]);

  const value = useMemo(() => ({ user, loading, signOut }), [user, loading, signOut]);

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession() {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error("useSession must be used inside SessionProvider");
  return ctx;
}
