export type PlaceCategory =
  | "sight"
  | "museum"
  | "food"
  | "nature"
  | "shopping"
  | "nightlife"
  | "stay"
  | "transit";

export interface Review {
  author: string;
  rating: number;
  date: string;
  text: string;
}

export interface Place {
  id: string;
  name: string;
  category: PlaceCategory;
  city: string;
  lat: number;
  lng: number;
  rating: number;
  reviewCount: number;
  ratingBreakdown: [number, number, number, number, number]; // 5★ → 1★
  priceLevel: 1 | 2 | 3 | 4;
  ticket?: string;
  typicalVisitMinutes: number;
  hours: { day: string; open: string }[];
  address: string;
  phone?: string;
  website?: string;
  tags: string[];
  blurb: string;
  photo: string;
  reviews: Review[];
}

export interface Stop {
  id: string;
  placeId: string;
  startTime: string;
  durationMinutes: number;
  travelToNextMinutes?: number;
  travelMode?: "walk" | "metro" | "car";
  note?: string;
}

export interface Day {
  id: string;
  date: string;
  title: string;
  stops: Stop[];
}

export interface Trip {
  id: string;
  name: string;
  destination: string;
  dateRange: string;
  travelers: number;
  cover: string;
  center: [number, number];
  days: Day[];
}
